"""Our Little World: serves the game and pairs two players over WebSockets.

The server never runs game logic. Whoever invites owns the world; the server
only keeps rooms of two and forwards each player's messages to the other.
"""
import json
import os
import secrets

from aiohttp import WSMsgType, web

PUBLIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "public")
CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
MAX_MESSAGE = 16 * 1024 * 1024  # photos travel as base64 JPEGs

rooms = {}  # code -> {"code", "host", "guest"}


def new_code():
    while True:
        code = "".join(secrets.choice(CODE_CHARS) for _ in range(6))
        if code not in rooms:
            return code


async def send(ws, payload):
    if ws is None or ws.closed:
        return
    try:
        await ws.send_str(payload if isinstance(payload, str) else json.dumps(payload))
    except ConnectionError:
        pass


async def websocket(request):
    ws = web.WebSocketResponse(heartbeat=25, max_msg_size=MAX_MESSAGE)
    await ws.prepare(request)
    room = None
    role = None
    try:
        async for msg in ws:
            if msg.type != WSMsgType.TEXT:
                continue
            if room is not None:
                other = room["guest"] if role == "host" else room["host"]
                await send(other, msg.data)
                continue
            try:
                data = json.loads(msg.data)
            except ValueError:
                continue
            if data.get("t") == "create":
                room = {"code": new_code(), "host": ws, "guest": None}
                role = "host"
                rooms[room["code"]] = room
                await send(ws, {"t": "created", "code": room["code"]})
            elif data.get("t") == "join":
                found = rooms.get(str(data.get("code", "")).strip().upper())
                if found is None:
                    await send(ws, {"t": "error", "reason": "not-found"})
                elif found["guest"] is not None:
                    await send(ws, {"t": "error", "reason": "full"})
                else:
                    room, role = found, "guest"
                    room["guest"] = ws
                    await send(ws, {"t": "joined"})
                    await send(room["host"], {"t": "peer-joined"})
    finally:
        if role == "host":
            rooms.pop(room["code"], None)
            guest = room["guest"]
            await send(guest, {"t": "host-left"})
            if guest is not None:
                await guest.close()
        elif role == "guest" and room["guest"] is ws:
            room["guest"] = None
            await send(room["host"], {"t": "peer-left"})
    return ws


async def index(request):
    return web.FileResponse(os.path.join(PUBLIC, "index.html"))


async def health(request):
    return web.Response(text="ok")


@web.middleware
async def no_stale_files(request, handler):
    response = await handler(request)
    if not isinstance(response, web.WebSocketResponse):
        response.headers["Cache-Control"] = "no-cache"
    return response


def make_app():
    app = web.Application(middlewares=[no_stale_files])
    app.router.add_get("/", index)
    app.router.add_get("/ws", websocket)
    app.router.add_get("/health", health)
    app.router.add_static("/", PUBLIC)
    return app


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8765"))
    print(f"Our Little World running at http://localhost:{port}", flush=True)
    web.run_app(make_app(), host="0.0.0.0", port=port, print=None)
