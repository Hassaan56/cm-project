#!/bin/sh
# Runs the game server locally: http://localhost:8765
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  python3 -m venv .venv && .venv/bin/pip install -q -r requirements.txt || exit 1
fi
PORT="${1:-8765}" exec .venv/bin/python server.py
