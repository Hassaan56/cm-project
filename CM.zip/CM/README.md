# Our Little World

A small 3D world for two people, built with Three.js. One person plays, invites a friend with a link, and the friend pops into the same world.

## Run it locally

```sh
./start.sh          # first run installs the server's one dependency into .venv
```

Then open http://localhost:8765. You need Python 3.10+ and internet (Three.js and the font load from a CDN).

## Deploy on Railway

1. Push this folder to a GitHub repo.
2. In Railway: **New Project → Deploy from GitHub repo** and pick the repo. Railway sees `requirements.txt`, installs it, and starts the server with the command in `railway.json`.
3. In the service: **Settings → Networking → Generate Domain**.
4. Open that domain. That's the link you and your friend use.

The server reads Railway's `PORT` automatically and answers `/health` for Railway's health check.

## Playing together

- Pick **Him** or **Her**, type your name and enter. On your own, only your character is in the world.
- Press <kbd>Esc</kbd> → **Invite a friend** → **Copy link**, and send it.
- Your friend opens the link, types their name and presses **Join**. They pop in right next to you as the other character.
- When they leave, their character disappears again. They can rejoin with the same link while your invite is open.

It's always the inviter's world: the time of day, TV, food and the photo wall are theirs. Photos the friend adds go on the inviter's wall and are saved in the inviter's browser.

## What's in the world

| Place | Alone | Together |
|---|---|---|
| Home: bed | Sleep, wake up next morning | Sleep together, cuddles under the blanket |
| Home: sofa | Watch TV | Cuddle and watch TV |
| Home: dining table | Dinner | Dinner together, hold hands across the table |
| Home: wardrobe | Change your outfit and hair | Same |
| Home: photo wall | Click a frame to add, view, change or remove a photo | Same, on the inviter's wall |
| Café Amour | Eat | Date night |
| Lakeside bench (west) | Watch the sunset / stars | Same, with cuddles |
| Red car | Drive the ring road | One drives, the other presses <kbd>E</kbd> to ride along |

Together, anywhere: <kbd>T</kbd> talk, <kbd>G</kbd> hug, <kbd>K</kbd> kiss, <kbd>Z</kbd> hold hands, <kbd>C</kbd> lean on the shoulder, <kbd>F</kbd> dance. While seated together, <kbd>C</kbd> cycles cuddles: head on the shoulder, holding hands, sitting on the lap, head on the lap (bench and sofa), snuggling (bed). If you walk up to a bench or bed where your friend is already sitting alone, you sit down next to them.

There's a full day/night cycle (1 in-game hour = 30 seconds). At night, lamps, windows, fireflies and car headlights come on.

## Saving

- Each browser saves its own player: character, name, outfit, hair, and the time of day of its own world.
- Photos are stored in the browser's IndexedDB and stay after reloads and restarts. Clearing site data or switching browsers loses them.

## Code layout

- `server.py`: serves `public/` and pairs two players over WebSockets (rooms of two; it just forwards messages)
- `public/js/main.js`: renderer, game loop, camera, input, car, HUD, multiplayer glue
- `public/js/net.js`: WebSocket client for the server
- `public/js/world.js`: terrain, house and interior, café, lake, trees, lights
- `public/js/character.js`: procedural characters, outfits, poses, network-driven movement
- `public/js/activities.js`: sit/sleep/eat/date/sunset/talk/hug/kiss/cuddle logic and dialogue
- `public/js/car.js`: drivable car
- `public/js/photos.js`: picture frames and IndexedDB storage
- `public/js/sky.js`: sky shader, sun/moon lighting, stars
- `public/js/ui.js`: toasts, speech bubbles, wardrobe panel, minimap, heart particles

Debug: `?debug&speed=5` exposes game objects on `window` and runs the simulation 5x faster.
