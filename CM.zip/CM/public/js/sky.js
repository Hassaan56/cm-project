import * as THREE from 'three';
import { clamp } from './utils.js';

// Keyframes indexed by sun elevation (sin of sun angle).
const KEYS = [
  { e: -1.0, top: '#03050f', hor: '#0b1030', light: '#7d8cff', li: 0.35, hemi: 0.18 },
  { e: -0.2, top: '#050816', hor: '#151b3d', light: '#7d8cff', li: 0.35, hemi: 0.2 },
  { e: -0.07, top: '#1a1c4a', hor: '#7a3b6e', light: '#ff6a4a', li: 0.2, hemi: 0.3 },
  { e: 0.0, top: '#2b3170', hor: '#ff6a3d', light: '#ff6a3d', li: 0.9, hemi: 0.45 },
  { e: 0.12, top: '#3f62a8', hor: '#ffb36b', light: '#ffa45c', li: 1.7, hemi: 0.65 },
  { e: 0.35, top: '#3f86d6', hor: '#cfe8ff', light: '#fff2dc', li: 2.6, hemi: 0.9 },
  { e: 1.0, top: '#3a7fd4', hor: '#cfe8ff', light: '#fff6e8', li: 2.9, hemi: 1.0 },
];
KEYS.forEach(k => { k.top = new THREE.Color(k.top); k.hor = new THREE.Color(k.hor); k.light = new THREE.Color(k.light); });

export class Sky {
  constructor(scene) {
    this.scene = scene;
    this.sunDir = new THREE.Vector3();
    this.night = 0;

    this.uniforms = {
      topColor: { value: new THREE.Color() },
      horColor: { value: new THREE.Color() },
      sunDir: { value: new THREE.Vector3(0, 1, 0) },
      sunColor: { value: new THREE.Color('#fff2c0') },
      moonDir: { value: new THREE.Vector3(0, -1, 0) },
    };
    const dome = new THREE.Mesh(
      new THREE.SphereGeometry(450, 32, 16),
      new THREE.ShaderMaterial({
        uniforms: this.uniforms,
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
        vertexShader: `varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
        fragmentShader: `
          uniform vec3 topColor, horColor, sunDir, sunColor, moonDir;
          varying vec3 vDir;
          void main(){
            vec3 d = normalize(vDir);
            float h = max(d.y, 0.0);
            vec3 col = mix(horColor, topColor, pow(h, 0.45));
            if (d.y < 0.0) col = mix(horColor, horColor * 0.6, clamp(-d.y * 4.0, 0.0, 1.0));
            float s = max(dot(d, sunDir), 0.0);
            col += sunColor * (pow(s, 900.0) * 3.0 + pow(s, 12.0) * 0.35 + pow(s, 3.0) * 0.12);
            float m = max(dot(d, moonDir), 0.0);
            col += vec3(0.9, 0.92, 1.0) * pow(m, 1500.0) * 2.0 + vec3(0.3,0.35,0.6) * pow(m, 30.0) * 0.15;
            gl_FragColor = vec4(col, 1.0);
            #include <tonemapping_fragment>
            #include <colorspace_fragment>
          }`,
      })
    );
    dome.renderOrder = -1;
    this.dome = dome;
    scene.add(dome);

    const starGeo = new THREE.BufferGeometry();
    const pts = [];
    for (let i = 0; i < 1500; i++) {
      const v = new THREE.Vector3(Math.random() * 2 - 1, Math.random() * 0.9 + 0.08, Math.random() * 2 - 1).normalize().multiplyScalar(400);
      pts.push(v.x, v.y, v.z);
    }
    starGeo.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
    this.stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 1.6, sizeAttenuation: false, transparent: true, opacity: 0, fog: false, depthWrite: false }));
    scene.add(this.stars);

    this.sun = new THREE.DirectionalLight(0xffffff, 2.5);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    const sc = this.sun.shadow.camera;
    sc.left = -45; sc.right = 45; sc.top = 45; sc.bottom = -45; sc.near = 1; sc.far = 200;
    this.sun.shadow.bias = -0.0005;
    this.sun.shadow.normalBias = 0.03;
    scene.add(this.sun, this.sun.target);

    this.hemi = new THREE.HemisphereLight(0xcfe8ff, 0x4a6b3a, 0.9);
    scene.add(this.hemi);

    scene.fog = new THREE.Fog(0xcfe8ff, 80, 320);
  }

  update(hours, center) {
    const a = ((hours - 6) / 12) * Math.PI;
    this.sunDir.set(Math.cos(a), Math.sin(a), -0.3).normalize();
    const e = this.sunDir.y;

    let i = 0;
    while (i < KEYS.length - 2 && e > KEYS[i + 1].e) i++;
    const k0 = KEYS[i], k1 = KEYS[i + 1];
    const t = clamp((e - k0.e) / (k1.e - k0.e), 0, 1);

    const u = this.uniforms;
    u.topColor.value.copy(k0.top).lerp(k1.top, t);
    u.horColor.value.copy(k0.hor).lerp(k1.hor, t);
    u.sunDir.value.copy(this.sunDir);
    u.moonDir.value.copy(this.sunDir).negate();
    u.sunColor.value.setRGB(1, 0.75 + clamp(e * 2, 0, 0.25), 0.45 + clamp(e * 2, 0, 0.4));

    this.night = clamp((0.05 - e) / 0.2, 0, 1);

    // Moon takes over as the key light at night.
    const dir = e > -0.04 ? this.sunDir : u.moonDir.value;
    this.sun.position.copy(center).addScaledVector(dir, 100);
    this.sun.target.position.copy(center);
    this.sun.color.copy(k0.light).lerp(k1.light, t);
    this.sun.intensity = k0.li + (k1.li - k0.li) * t;
    this.hemi.intensity = k0.hemi + (k1.hemi - k0.hemi) * t;
    this.hemi.color.copy(u.topColor.value).lerp(new THREE.Color(1, 1, 1), 0.4);

    this.scene.fog.color.copy(u.horColor.value);
    this.dome.position.copy(center);
    this.stars.position.copy(center);
    this.stars.material.opacity = this.night;
    this.stars.rotation.y = hours * 0.02;
  }
}
