import * as THREE from 'three';
import { canvasTexture } from './utils.js';

const DB_NAME = 'our-little-world', STORE = 'photos';

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function tx(mode, fn) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORE, mode);
    const req = fn(t.objectStore(STORE));
    t.oncomplete = () => resolve(req?.result);
    t.onerror = () => reject(t.error);
  });
}

const getPhoto = id => tx('readonly', s => s.get(id));
const putPhoto = (id, blob) => tx('readwrite', s => s.put(blob, id));
const deletePhoto = id => tx('readwrite', s => s.delete(id));

function plusTexture(w, h) {
  const px = 256, py = Math.round((256 * h) / w);
  return canvasTexture(px, py, (g, W, H) => {
    g.fillStyle = '#f4ede2'; g.fillRect(0, 0, W, H);
    g.strokeStyle = '#c9b49a'; g.lineWidth = 4; g.setLineDash([12, 8]);
    g.strokeRect(14, 14, W - 28, H - 28);
    g.setLineDash([]);
    const r = Math.min(W, H) * 0.18;
    g.fillStyle = '#ff7a90';
    g.beginPath(); g.arc(W / 2, H / 2 - 10, r, 0, Math.PI * 2); g.fill();
    g.strokeStyle = '#fff'; g.lineWidth = r * 0.22; g.lineCap = 'round';
    g.beginPath(); g.moveTo(W / 2 - r * 0.5, H / 2 - 10); g.lineTo(W / 2 + r * 0.5, H / 2 - 10);
    g.moveTo(W / 2, H / 2 - 10 - r * 0.5); g.lineTo(W / 2, H / 2 - 10 + r * 0.5); g.stroke();
    g.fillStyle = '#8a7058'; g.font = 'bold 20px Quicksand, sans-serif'; g.textAlign = 'center';
    g.fillText('Add photo', W / 2, H / 2 + r + 18);
  });
}

// Crops the image to the frame's aspect ratio (cover) and returns a canvas.
async function fitToFrame(blob, aspect) {
  const img = await createImageBitmap(blob);
  const W = aspect >= 1 ? 1200 : Math.round(1200 * aspect);
  const H = aspect >= 1 ? Math.round(1200 / aspect) : 1200;
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const s = Math.max(W / img.width, H / img.height);
  const dw = img.width * s, dh = img.height * s;
  c.getContext('2d').drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
  img.close?.();
  return c;
}

export class Photos {
  constructor(frames, toast) {
    this.frames = frames;
    this.toast = toast;
    this.menu = document.getElementById('photoMenu');
    this.input = document.getElementById('fileInput');
    this.lightbox = document.getElementById('lightbox');
    this.active = null;
    this.remoteSave = null; // set while visiting a friend: saves go to their wall instead
    this.onChange = null;   // called after a local save/remove so it can be shared

    for (const f of frames) {
      f.plus = plusTexture(f.w, f.h);
      this.show(f, f.plus);
      f.mesh.userData.frame = f;
    }
    this.loadAll();
    navigator.storage?.persist?.();

    this.input.addEventListener('change', () => this.onFile());
    this.menu.addEventListener('click', e => {
      const act = e.target.dataset.act;
      if (!act) return;
      this.hideMenu();
      if (act === 'view') this.view(this.active);
      if (act === 'replace') this.pick(this.active);
      if (act === 'remove') this.remove(this.active);
    });
    this.lightbox.addEventListener('click', () => this.lightbox.classList.add('hidden'));
    window.addEventListener('pointerdown', e => { if (!this.menu.contains(e.target)) this.hideMenu(); });
  }

  get meshes() { return this.frames.map(f => f.mesh); }

  show(f, tex) {
    const m = f.mesh.material;
    if (f.tex && f.tex !== f.plus) f.tex.dispose();
    f.tex = tex;
    m.map = tex;
    m.emissiveMap = tex;
    m.needsUpdate = true;
  }

  async loadAll() {
    for (const f of this.frames) {
      try {
        const blob = await getPhoto(f.id);
        if (this.remoteSave) return;
        if (blob) await this.applyBlob(f, blob);
      } catch (err) {
        console.warn('Could not load photo', f.id, err);
      }
    }
  }

  async applyBlob(f, blob) {
    const c = await fitToFrame(blob, f.w / f.h);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    this.show(f, tex);
    f.blob = blob;
  }

  click(f, x, y) {
    this.active = f;
    if (!f.blob) return this.pick(f);
    this.menu.style.left = `${Math.min(x, innerWidth - 170)}px`;
    this.menu.style.top = `${Math.min(y, innerHeight - 130)}px`;
    this.menu.classList.remove('hidden');
  }

  hideMenu() { this.menu.classList.add('hidden'); }

  pick(f) {
    this.active = f;
    this.input.value = '';
    this.input.click();
  }

  async onFile() {
    const file = this.input.files?.[0], f = this.active;
    if (!file || !f) return;
    try {
      const c = await fitToFrame(file, f.w / f.h);
      const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.9));
      if (this.remoteSave) {
        this.remoteSave(f.id, blob);
        this.toast('Photo sent to the wall');
      } else {
        await this.store(f.id, blob);
        this.toast('Photo saved to the wall');
      }
    } catch (err) {
      console.error(err);
      this.toast('Sorry, that image could not be loaded');
    }
  }

  async remove(f) {
    if (this.remoteSave) this.remoteSave(f.id, null);
    else await this.store(f.id, null);
    this.toast('Photo removed');
  }

  frame(id) { return this.frames.find(f => f.id === id); }

  // Saves to this browser and shows it; blob null removes.
  async store(id, blob) {
    const f = this.frame(id);
    if (!f) return;
    if (blob) {
      await putPhoto(id, blob);
      await this.applyBlob(f, blob);
    } else {
      await deletePhoto(id);
      f.blob = null;
      this.show(f, f.plus);
    }
    this.onChange?.(id, blob);
  }

  // Shows a friend's photo without saving it here.
  async display(id, blob) {
    const f = this.frame(id);
    if (!f) return;
    if (blob) await this.applyBlob(f, blob);
    else { f.blob = null; this.show(f, f.plus); }
  }

  clearDisplay() {
    for (const f of this.frames) { f.blob = null; this.show(f, f.plus); }
  }

  view(f) {
    if (!f?.blob) return;
    const img = document.getElementById('lightboxImg');
    if (img.src) URL.revokeObjectURL(img.src);
    img.src = URL.createObjectURL(f.blob);
    this.lightbox.classList.remove('hidden');
  }
}
