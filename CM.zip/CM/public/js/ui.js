import * as THREE from 'three';
import { OUTFITS, HAIR_COLORS } from './character.js';
import { canvasTexture } from './utils.js';

const $ = id => document.getElementById(id);

export const ui = {
  toast(text) {
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = text;
    $('toasts').appendChild(el);
    setTimeout(() => el.remove(), 3800);
  },

  prompt(html) {
    const el = $('prompt');
    if (!html) { el.classList.add('hidden'); return; }
    if (el.dataset.html !== html) { el.innerHTML = html; el.dataset.html = html; }
    el.classList.remove('hidden');
  },

  hints(text) {
    const el = $('hints');
    if (el.textContent !== text) el.textContent = text;
  },

  fade(on) { $('fade').classList.toggle('on', on); },

  bubbles: [],
  say(char, text, dur = 2.8) {
    this.bubbles.filter(b => b.char === char).forEach(b => b.el.remove());
    this.bubbles = this.bubbles.filter(b => b.char !== char);
    const el = document.createElement('div');
    el.className = 'bubble';
    el.textContent = text;
    $('bubbles').appendChild(el);
    this.bubbles.push({ char, el, until: performance.now() + dur * 1000 });
  },
  clearBubbles() { this.bubbles.forEach(b => b.el.remove()); this.bubbles = []; },
  updateBubbles(camera) {
    const now = performance.now(), v = new THREE.Vector3();
    this.bubbles = this.bubbles.filter(b => {
      if (now > b.until || !b.char.root.visible) { b.el.remove(); return false; }
      b.char.headWorld(v).project(camera);
      const hidden = v.z > 1;
      b.el.style.display = hidden ? 'none' : '';
      b.el.style.left = `${((v.x + 1) / 2) * innerWidth}px`;
      b.el.style.top = `${((1 - v.y) / 2) * innerHeight}px`;
      return true;
    });
  },

  openWardrobe(chars, startIndex, onChange) {
    const panel = $('wardrobe');
    let idx = startIndex;
    const render = () => {
      const ch = chars[idx];
      $('wardrobeTabs').innerHTML = '';
      chars.forEach((c, i) => {
        const b = document.createElement('button');
        b.textContent = c.name;
        b.className = i === idx ? 'active' : '';
        b.onclick = () => { idx = i; render(); };
        $('wardrobeTabs').appendChild(b);
      });
      const grid = $('outfitGrid');
      grid.innerHTML = '';
      OUTFITS[ch.gender].forEach((o, i) => {
        const card = document.createElement('div');
        card.className = 'outfit' + (ch.outfitIndex === i ? ' selected' : '');
        card.innerHTML = `<div class="sw"><span style="background:${o.top}"></span><span style="background:${o.bottom}"></span><span style="background:${o.shoes}"></span></div>${o.name}`;
        card.onclick = () => { ch.setOutfit(i); onChange(); render(); };
        grid.appendChild(card);
      });
      const hair = $('hairRow');
      hair.innerHTML = '';
      for (const c of HAIR_COLORS) {
        const s = document.createElement('span');
        s.style.background = c;
        if (ch.hairColor === c) s.className = 'selected';
        s.onclick = () => { ch.setHair(c); onChange(); render(); };
        hair.appendChild(s);
      }
    };
    render();
    panel.classList.remove('hidden');
  },
};

export class Minimap {
  constructor(world) {
    this.canvas = $('minimap');
    this.g = this.canvas.getContext('2d');
    this.scale = 90 / 95;
    this.bg = document.createElement('canvas');
    this.bg.width = this.bg.height = 180;
    const g = this.bg.getContext('2d'), s = this.scale, c = 90;
    const P = (x, z) => [c + x * s, c + z * s];
    g.fillStyle = '#5d9a48'; g.beginPath(); g.arc(c, c, 90, 0, Math.PI * 2); g.fill();
    g.strokeStyle = '#55555e'; g.lineWidth = 8 * s; g.beginPath(); g.arc(c, c, 45 * s, 0, Math.PI * 2); g.stroke();
    g.fillStyle = '#4aa3d8'; g.beginPath(); g.arc(...P(-70, 0), 13 * s, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#c0504d'; g.fillRect(...P(-8, -16), 16 * s, 12 * s);
    g.fillStyle = '#e8b04a'; g.fillRect(...P(19, 15), 7 * s, 11 * s);
    g.fillStyle = '#d8c8a8'; g.fillRect(...P(-1, -4), 2 * s, 45 * s);
    g.fillStyle = '#7a5236'; g.fillRect(...P(-54.5, -1), 2, 4);
    g.font = 'bold 10px Quicksand, sans-serif'; g.fillStyle = '#fff'; g.textAlign = 'center';
    g.fillText('Home', ...P(0, -18)); g.fillText('Café', ...P(22, 31)); g.fillText('Lake', ...P(-70, -15));
    this.P = P;
  }

  draw(chars, active, car) {
    const g = this.g, P = this.P;
    g.clearRect(0, 0, 180, 180);
    g.drawImage(this.bg, 0, 0);
    g.save();
    g.translate(...P(car.pos.x, car.pos.z)); g.rotate(-car.yaw);
    g.fillStyle = '#ff3b4e'; g.fillRect(-2.5, -4, 5, 8);
    g.restore();
    chars.forEach((ch, i) => {
      if (!ch.root.visible) return;
      const [x, y] = P(ch.pos.x, ch.pos.z);
      g.fillStyle = ch.female ? '#ff8fab' : '#6fb2ff';
      g.strokeStyle = '#fff'; g.lineWidth = i === active ? 2 : 1;
      g.beginPath(); g.arc(x, y, i === active ? 5 : 3.5, 0, Math.PI * 2); g.fill(); g.stroke();
    });
  }
}

export class Hearts {
  constructor(scene) {
    const tex = canvasTexture(64, 64, (g) => {
      g.fillStyle = '#ff5d7a';
      g.beginPath();
      g.moveTo(32, 56);
      g.bezierCurveTo(2, 34, 6, 6, 32, 20);
      g.bezierCurveTo(58, 6, 62, 34, 32, 56);
      g.fill();
    });
    this.pool = Array.from({ length: 50 }, () => {
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
      s.visible = false;
      scene.add(s);
      return { s, life: 0, vel: new THREE.Vector3() };
    });
  }

  burst(pos, n = 6) {
    for (let i = 0; i < n; i++) {
      const p = this.pool.find(p => p.life <= 0);
      if (!p) return;
      p.life = 1.8 + Math.random();
      p.s.position.set(pos.x + (Math.random() - 0.5) * 0.6, pos.y + Math.random() * 0.3, pos.z + (Math.random() - 0.5) * 0.6);
      p.vel.set((Math.random() - 0.5) * 0.4, 0.6 + Math.random() * 0.5, (Math.random() - 0.5) * 0.4);
      p.s.visible = true;
    }
  }

  update(dt) {
    for (const p of this.pool) {
      if (p.life <= 0) continue;
      p.life -= dt;
      p.s.position.addScaledVector(p.vel, dt);
      const sc = 0.25 * Math.min(1, p.life);
      p.s.scale.set(sc, sc, sc);
      p.s.material.opacity = Math.min(1, p.life);
      if (p.life <= 0) p.s.visible = false;
    }
  }
}
