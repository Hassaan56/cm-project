import * as THREE from 'three';
import { mat, cyl, box, clamp, damp, dampAngle, resolveCircle } from './utils.js';

export const OUTFITS = {
  male: [
    { name: 'Casual', top: '#3b7dd8', bottom: '#2d3a4a', shoes: '#f2f2f2', type: 'pants' },
    { name: 'Date Suit', top: '#1f2430', bottom: '#1f2430', shoes: '#3a2416', type: 'pants', tie: '#c0283c' },
    { name: 'Sporty', top: '#e94f37', bottom: '#222222', shoes: '#ffffff', type: 'shorts' },
    { name: 'Summer', top: '#f5d76e', bottom: '#d9c3a0', shoes: '#8a5a3a', type: 'shorts', hat: 'cap', hatColor: '#3b7dd8' },
    { name: 'Cozy Sweater', top: '#8a4b3a', bottom: '#3d3d46', shoes: '#5a3a28', type: 'pants' },
    { name: 'Pajamas', top: '#7aa6c2', bottom: '#7aa6c2', shoes: '#c9b29b', type: 'pants' },
  ],
  female: [
    { name: 'Sundress', top: '#ff8fab', bottom: '#ff8fab', shoes: '#ffffff', type: 'skirt' },
    { name: 'Evening Gown', top: '#8e1c3b', bottom: '#8e1c3b', shoes: '#222222', type: 'gown' },
    { name: 'Casual Jeans', top: '#ffffff', bottom: '#4a6fa5', shoes: '#ff8fab', type: 'pants' },
    { name: 'Summer', top: '#6ad1c5', bottom: '#f7f1e3', shoes: '#d9a066', type: 'skirt', hat: 'sunhat', hatColor: '#f3d9a4' },
    { name: 'Cozy Knit', top: '#e8c9a0', bottom: '#5b4a6e', shoes: '#4a3328', type: 'pants' },
    { name: 'Pajamas', top: '#c3a6e8', bottom: '#c3a6e8', shoes: '#f0e0f0', type: 'pants' },
  ],
};
export const HAIR_COLORS = ['#1b120c', '#3b2416', '#6b4226', '#a8743f', '#e0c27a', '#b8b8c0', '#8e2b2b', '#ff9ac2'];

const SKIN = '#f1c6a8';
const LEG = 0.44, FOOT = 0.06, HIP_Y = LEG * 2 + FOOT;

const POSE_KEYS = ['thL', 'thR', 'shL', 'shR', 'aLx', 'aLz', 'aRx', 'aRz', 'eL', 'eR', 'by', 'brx', 'bry', 'tx', 'tz', 'hx', 'hz', 'sk'];

const DOOR_OUT = new THREE.Vector3(0, 0, -2.6), DOOR_IN = new THREE.Vector3(0, 0, -5.4);
export const inHouse = p => p.x > -8 && p.x < 8 && p.z > -16 && p.z < -4;

function steerGoal(from, to) {
  const fi = inHouse(from), ti = inHouse(to);
  if (fi === ti) return to;
  if (fi) return Math.abs(from.x) < 0.9 && from.z > -5.6 ? DOOR_OUT : DOOR_IN;
  return Math.abs(from.x) < 0.9 && from.z < -2.3 ? DOOR_IN : DOOR_OUT;
}

export class Character {
  constructor({ gender, name, outfit = 0, hair }) {
    this.gender = gender;
    this.name = name;
    this.female = gender === 'female';
    this.scale = this.female ? 0.92 : 1;
    this.root = new THREE.Group();
    this.body = new THREE.Group();
    this.model = new THREE.Group();
    this.model.scale.setScalar(this.scale);
    this.root.add(this.body);
    this.body.add(this.model);

    this.mode = 'free';
    this.vel = new THREE.Vector3();
    this.vy = 0;
    this.speed = 0;
    this.yaw = 0;
    this.phase = 0;
    this.time = 0;
    this.pose = 'idle';
    this.poseOpts = {};
    this.cur = Object.fromEntries(POSE_KEYS.map(k => [k, 0]));
    this.snap = null;
    this.nav = null;

    this.build();
    this.setOutfit(outfit);
    this.setHair(hair || (this.female ? '#5a3825' : '#2b1d14'));
  }

  build() {
    const M = this.mats = {
      skin: mat(SKIN), hair: mat('#222', { roughness: 0.6 }), top: mat('#fff'), bottom: mat('#333'),
      thigh: mat('#333'), shin: mat('#333'), shoe: mat('#fff'), hat: mat('#fff'), tie: mat('#c00'),
      dark: mat('#2a1a1a'), blush: mat('#ff9aa8', { transparent: true, opacity: 0.6 }),
    };
    const f = this.female;
    const m = this.model;

    this.legs = [-1, 1].map(side => {
      const thigh = new THREE.Group();
      thigh.position.set(side * 0.11, HIP_Y, 0);
      const tm = cyl(0.075, 0.065, LEG, M.thigh, 10); tm.position.y = -LEG / 2; thigh.add(tm);
      const knee = new THREE.Group(); knee.position.y = -LEG; thigh.add(knee);
      const sm = cyl(0.062, 0.05, LEG, M.shin, 10); sm.position.y = -LEG / 2; knee.add(sm);
      const shoe = box(0.12, 0.08, 0.25, M.shoe, 0, -LEG - 0.02, 0.045); knee.add(shoe);
      m.add(thigh);
      return { thigh, knee };
    });

    const pelvis = cyl(0.17, 0.15, 0.16, M.thigh, 14); pelvis.position.y = HIP_Y; m.add(pelvis);
    this.pelvis = pelvis;

    const skirtPivot = new THREE.Group(); skirtPivot.position.y = HIP_Y + 0.06; m.add(skirtPivot);
    const skirt = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.36, 1, 18, 1, true), M.bottom);
    skirt.material.side = THREE.DoubleSide;
    skirt.castShadow = true;
    skirtPivot.add(skirt);
    this.skirt = skirt; this.skirtPivot = skirtPivot;

    const torso = new THREE.Group(); torso.position.y = HIP_Y; m.add(torso);
    this.torso = torso;
    const tMesh = cyl(f ? 0.17 : 0.21, f ? 0.15 : 0.18, 0.58, M.top, 16); tMesh.position.y = 0.3; torso.add(tMesh);
    const shoulders = new THREE.Mesh(new THREE.SphereGeometry(f ? 0.17 : 0.21, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), M.top);
    shoulders.scale.y = 0.4; shoulders.position.y = 0.58; shoulders.castShadow = true; torso.add(shoulders);
    const tie = box(0.06, 0.34, 0.02, M.tie, 0, 0.4, f ? 0.17 : 0.205); torso.add(tie); this.tie = tie;

    const sx = f ? 0.22 : 0.265;
    this.arms = [-1, 1].map(side => {
      const sh = new THREE.Group(); sh.position.set(side * sx, 0.55, 0); torso.add(sh);
      const up = cyl(0.065, 0.055, 0.3, M.top, 10); up.position.y = -0.15; sh.add(up);
      const el = new THREE.Group(); el.position.y = -0.3; sh.add(el);
      const fo = cyl(0.05, 0.045, 0.27, M.skin, 10); fo.position.y = -0.135; el.add(fo);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), M.skin); hand.position.y = -0.3; hand.castShadow = true; el.add(hand);
      return { sh, el };
    });

    const neck = cyl(0.05, 0.055, 0.1, M.skin, 10); neck.position.y = 0.64; torso.add(neck);
    const head = new THREE.Group(); head.position.y = 0.8; torso.add(head);
    this.head = head;
    const hm = new THREE.Mesh(new THREE.SphereGeometry(0.15, 20, 16), M.skin); hm.castShadow = true; head.add(hm);
    for (const s of [-1, 1]) {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.022, 8, 6), M.dark); eye.position.set(s * 0.055, 0.015, 0.135); head.add(eye);
      const bl = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 6), M.blush); bl.scale.set(1, 0.6, 0.3); bl.position.set(s * 0.085, -0.03, 0.125); head.add(bl);
    }
    const mouth = new THREE.Mesh(new THREE.TorusGeometry(0.03, 0.007, 6, 12, Math.PI), M.dark);
    mouth.rotation.z = Math.PI; mouth.position.set(0, -0.045, 0.142); head.add(mouth);
    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.018, 8, 6), M.skin); nose.position.set(0, -0.01, 0.15); head.add(nose);

    const hairTop = new THREE.Mesh(new THREE.SphereGeometry(0.162, 20, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), M.hair);
    hairTop.rotation.x = -0.25; hairTop.position.set(0, 0.01, -0.01); hairTop.castShadow = true; head.add(hairTop);
    if (f) {
      const back = new THREE.Mesh(new THREE.CapsuleGeometry(0.15, 0.3, 6, 12), M.hair);
      back.scale.set(1, 1, 0.55); back.position.set(0, -0.14, -0.07); back.castShadow = true; head.add(back);
      for (const s of [-1, 1]) {
        const side = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.22, 4, 8), M.hair);
        side.position.set(s * 0.13, -0.1, 0.02); head.add(side);
      }
    } else {
      const back = new THREE.Mesh(new THREE.SphereGeometry(0.158, 16, 10, 0, Math.PI * 2, Math.PI * 0.4, Math.PI * 0.3), M.hair);
      back.rotation.x = 0.5; back.position.z = -0.01; head.add(back);
    }

    this.cap = new THREE.Group();
    const capTop = new THREE.Mesh(new THREE.SphereGeometry(0.17, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), M.hat);
    capTop.position.y = 0.03; this.cap.add(capTop);
    const brim = box(0.22, 0.02, 0.16, M.hat, 0, 0.04, 0.17); this.cap.add(brim);
    head.add(this.cap);

    this.sunhat = new THREE.Group();
    const crown = new THREE.Mesh(new THREE.SphereGeometry(0.17, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), M.hat);
    crown.position.y = 0.04; this.sunhat.add(crown);
    const wide = cyl(0.34, 0.34, 0.015, M.hat, 24); wide.position.y = 0.06; this.sunhat.add(wide);
    const band = cyl(0.172, 0.172, 0.04, mat('#d9536b'), 16); band.position.y = 0.08; this.sunhat.add(band);
    this.sunhat.rotation.x = -0.12;
    head.add(this.sunhat);

    const ring = new THREE.Mesh(new THREE.RingGeometry(0.4, 0.5, 32), new THREE.MeshBasicMaterial({ color: '#ffd27a', transparent: true, opacity: 0.55, depthWrite: false }));
    ring.rotation.x = -Math.PI / 2; ring.position.y = 0.03;
    this.ring = ring;
    this.root.add(ring);

    this.root.traverse(o => { if (o.isMesh && o !== ring) o.castShadow = true; });
  }

  setOutfit(i) {
    const list = OUTFITS[this.gender];
    this.outfitIndex = i = clamp(i, 0, list.length - 1);
    const o = this.outfit = list[i];
    const M = this.mats;
    M.top.color.set(o.top);
    M.bottom.color.set(o.bottom);
    M.shoe.color.set(o.shoes);
    const legsCovered = o.type === 'pants';
    M.thigh.color.set(o.type === 'skirt' || o.type === 'gown' ? SKIN : o.bottom);
    M.shin.color.set(legsCovered ? o.bottom : SKIN);
    this.pelvis.material = o.type === 'skirt' || o.type === 'gown' ? M.bottom : M.thigh;
    const skirtLen = o.type === 'gown' ? 0.88 : o.type === 'skirt' ? 0.46 : 0;
    this.skirt.visible = skirtLen > 0;
    this.skirtLen = skirtLen;
    if (skirtLen) {
      this.skirt.scale.set(o.type === 'gown' ? 1.1 : 1, skirtLen, o.type === 'gown' ? 1.1 : 1);
      this.skirt.position.y = -skirtLen / 2;
    }
    this.tie.visible = !!o.tie;
    if (o.tie) M.tie.color.set(o.tie);
    this.cap.visible = o.hat === 'cap';
    this.sunhat.visible = o.hat === 'sunhat';
    if (o.hat) M.hat.color.set(o.hatColor);
  }

  setHair(color) {
    this.hairColor = color;
    this.mats.hair.color.set(color);
  }

  get pos() { return this.root.position; }

  headWorld(out) {
    return this.head.getWorldPosition(out).add({ x: 0, y: 0.32, z: 0 });
  }

  setPose(pose, opts = {}) {
    if (this.pose !== pose) this.poseTime = 0;
    this.pose = pose;
    this.poseOpts = opts;
  }

  snapTo(pos, yaw, pose, opts = {}, dur = 0.6, onDone) {
    this.mode = 'snap';
    this.nav = null;
    this.vel.set(0, 0, 0);
    this.speed = 0;
    this.snap = { from: this.pos.clone(), fromYaw: this.yaw, to: pos.clone(), toYaw: yaw, t: 0, dur, onDone };
    this.setPose(pose, opts);
  }

  navigate(target, onArrive, run = false) {
    this.mode = 'nav';
    this.nav = { target: target.clone(), onArrive, run, stuckT: 0, check: this.pos.clone() };
  }

  follow() { this.mode = 'follow'; this.nav = null; this.setPose('idle'); }

  // Springs in from nothing, for when a friend comes online.
  popIn() { this.popT = 0; this.root.scale.setScalar(0.01); }

  update(dt, ctx) {
    this.time += dt;
    if (this.popT !== undefined) {
      this.popT = Math.min(1, this.popT + dt / 0.5);
      const t = this.popT, k = 1.70158;
      this.root.scale.setScalar(Math.max(0.01, 1 + (k + 1) * (t - 1) ** 3 + k * (t - 1) ** 2));
      if (t >= 1) { this.popT = undefined; this.root.scale.setScalar(1); }
    }
    this.poseTime = (this.poseTime || 0) + dt;
    if (this.mode === 'player') this.updatePlayer(dt, ctx);
    else if (this.mode === 'follow' || this.mode === 'nav') this.updateAI(dt, ctx);
    else if (this.mode === 'snap') this.updateSnap(dt);
    else if (this.mode === 'remote') this.updateRemote(dt);
    else this.speed = damp(this.speed, 0, 10, dt);
    this.root.rotation.y = this.yaw;
    this.animate(dt);
  }

  netState() {
    const r = v => Math.round(v * 1000) / 1000;
    return { p: this.pos.toArray().map(r), y: r(this.yaw), v: r(this.speed), pose: this.pose, o: this.poseOpts, vis: this.root.visible };
  }

  // Target state from the network; updateRemote eases toward it.
  setNet(s) {
    const n = this.net ||= { pos: new THREE.Vector3() };
    n.pos.fromArray(s.p);
    n.yaw = s.y;
    n.speed = s.v;
    n.pose = s.pose;
    n.opts = s.o || {};
    n.vis = s.vis !== false;
    if (!n.seen || this.pos.distanceTo(n.pos) > 6) { this.pos.copy(n.pos); this.yaw = n.yaw; }
    n.seen = true;
  }

  updateRemote(dt) {
    const n = this.net;
    if (!n?.seen) return;
    this.pos.lerp(n.pos, 1 - Math.exp(-14 * dt));
    this.yaw = dampAngle(this.yaw, n.yaw, 14, dt);
    this.speed = n.speed;
    this.root.visible = n.vis;
    this.setPose(n.pose, n.opts);
  }

  updateSnap(dt) {
    const s = this.snap;
    s.t = Math.min(1, s.t + dt / s.dur);
    const e = s.t * s.t * (3 - 2 * s.t);
    this.pos.lerpVectors(s.from, s.to, e);
    this.yaw = s.fromYaw + Math.atan2(Math.sin(s.toYaw - s.fromYaw), Math.cos(s.toYaw - s.fromYaw)) * e;
    if (s.t >= 1) {
      this.snap = null;
      this.mode = 'busy';
      s.onDone?.();
    }
  }

  moveToward(dt, dirX, dirZ, targetSpeed, colliders) {
    const len = Math.hypot(dirX, dirZ);
    const tx = len > 0 ? (dirX / len) * targetSpeed : 0, tz = len > 0 ? (dirZ / len) * targetSpeed : 0;
    this.vel.x = damp(this.vel.x, tx, 10, dt);
    this.vel.z = damp(this.vel.z, tz, 10, dt);
    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;
    this.speed = Math.hypot(this.vel.x, this.vel.z);
    if (this.speed > 0.3) this.yaw = dampAngle(this.yaw, Math.atan2(this.vel.x, this.vel.z), 12, dt);
    this.vy -= 22 * dt;
    this.pos.y += this.vy * dt;
    if (this.pos.y <= 0) { this.pos.y = 0; this.vy = 0; }
    resolveCircle(this.pos, 0.35, colliders);
  }

  updatePlayer(dt, { input, camYaw, colliders }) {
    const fx = -Math.sin(camYaw), fz = -Math.cos(camYaw);
    const rx = Math.cos(camYaw), rz = -Math.sin(camYaw);
    const mx = fx * input.z + rx * input.x, mz = fz * input.z + rz * input.x;
    if (input.jump && this.pos.y <= 0.001) this.vy = 6.5;
    this.moveToward(dt, mx, mz, input.run ? 6.5 : 3.2, colliders);
    if (this.pose !== 'wave' || this.speed > 0.5) this.setPose(this.speed > 0.2 ? 'walk' : 'idle');
  }

  updateAI(dt, { leader, colliders }) {
    let target, stopDist, run;
    if (this.mode === 'follow') {
      target = leader.pos;
      const d = this.pos.distanceTo(target);
      stopDist = this.speed > 0.5 ? 1.8 : 3;
      run = d > 8;
    } else {
      target = this.nav.target;
      stopDist = 0.15;
      run = this.nav.run || this.pos.distanceTo(target) > 8;
    }
    const goal = steerGoal(this.pos, target);
    const dx = goal.x - this.pos.x, dz = goal.z - this.pos.z;
    const dist = Math.hypot(this.pos.x - target.x, this.pos.z - target.z);
    const moving = dist > stopDist;
    this.moveToward(dt, moving ? dx : 0, moving ? dz : 0, run ? 6.2 : 3.0, colliders);
    if (this.mode === 'nav' && !moving) {
      const cb = this.nav.onArrive;
      this.nav = null;
      this.mode = 'busy';
      this.vel.set(0, 0, 0);
      cb?.();
      return;
    }
    if (this.pose !== 'wave' || moving) this.setPose(this.speed > 0.2 ? 'walk' : 'idle');

    // Stuck recovery: teleport if barely moved for a while.
    if (moving) {
      this.stuckT = (this.stuckT || 0) + dt;
      if (this.stuckT > 2.5) {
        if (this.pos.distanceTo(this.stuckCheck || this.pos) < 0.6) {
          if (this.mode === 'nav') this.pos.copy(target);
          else this.pos.set(leader.pos.x - Math.sin(leader.yaw) * 1.5, 0, leader.pos.z - Math.cos(leader.yaw) * 1.5);
          resolveCircle(this.pos, 0.35, colliders);
        }
        this.stuckT = 0;
        this.stuckCheck = this.pos.clone();
      }
    } else {
      this.stuckT = 0;
      this.stuckCheck = this.pos.clone();
    }
  }

  animate(dt) {
    const T = { thL: 0, thR: 0, shL: 0, shR: 0, aLx: 0, aLz: 0.08, aRx: 0, aRz: -0.08, eL: -0.1, eR: -0.1, by: 0, brx: 0, bry: 0, tx: 0, tz: 0, hx: 0, hz: 0, sk: 0 };
    const t = this.time, o = this.poseOpts, s = this.scale;
    const sit = seatH => {
      T.thL = T.thR = -Math.PI / 2; T.shL = T.shR = Math.PI / 2;
      T.by = seatH - HIP_Y * s;
      T.aLx = T.aRx = -0.45; T.eL = T.eR = -0.7; T.sk = -0.9;
    };
    // Reaching toward a partner standing/sitting at local +X (side 1) or -X (side -1).
    const armTo = (kind, side) => {
      const K = side > 0 ? { x: 'aLx', z: 'aLz', e: 'eL' } : { x: 'aRx', z: 'aRz', e: 'eR' };
      if (kind === 'around') { T[K.z] = side * 1.34; T[K.x] = -0.2; T[K.e] = -1.15; }
      else if (kind === 'hold') { T[K.z] = side * 0.44; T[K.x] = -0.14; T[K.e] = -0.12; T.tz = -side * 0.05; }
      else if (kind === 'stroke') { T[K.z] = side * 0.9; T[K.x] = -0.55 + Math.sin(t * 1.3) * 0.14; T[K.e] = -0.5; T.hx = 0.3; T.hz = -side * 0.1; }
      else if (kind === 'reach') { T[K.z] = side * 0.2; T[K.x] = -1.15; T[K.e] = -0.45; T.tx = 0.12; }
      else if (kind === 'wrap') {
        T.aLx = T.aRx = -1.0; T.aLz = -0.3; T.aRz = 0.3; T.eL = T.eR = -1.35;
        T.hz = -side * 0.12; T.hx = -0.04;
      }
    };
    switch (this.pose) {
      case 'idle':
        T.aLz += Math.sin(t * 1.5) * 0.02; T.tx = Math.sin(t * 1.5) * 0.015;
        break;
      case 'walk': {
        const a = clamp(this.speed / 3.4, 0, 1.25);
        this.phase += dt * (3 + this.speed * 2.1);
        const p = this.phase;
        T.thL = Math.sin(p) * 0.65 * a; T.thR = -T.thL;
        T.shL = Math.max(0, Math.cos(p)) * 0.9 * a; T.shR = Math.max(0, -Math.cos(p)) * 0.9 * a;
        T.aLx = -T.thL * 0.8; T.aRx = -T.thR * 0.8;
        T.eL = T.eR = -0.25 - 0.3 * a;
        T.by = Math.abs(Math.sin(p)) * 0.045 * a;
        T.tx = 0.06 * a;
        if (this.pos.y > 0.05) { T.thL = -0.7; T.shL = 1.1; T.thR = 0.2; T.shR = 0.5; T.aLz = 0.6; T.aRz = -0.6; }
        break;
      }
      case 'sit':
        sit(o.seatH ?? 0.47);
        T.hz = o.lean || 0;
        T.hx = o.lookUp || 0;
        if (o.lean) { T.tx = 0; T.brx = 0; }
        break;
      case 'eat': {
        sit(o.seatH ?? 0.47);
        const c = (Math.sin(t * 2.6) + 1) / 2;
        T.aRx = -0.6 - 0.5 * c; T.eR = -1.0 - 1.1 * c; T.aRz = 0.15;
        T.aLx = -0.7; T.eL = -0.6;
        T.hx = 0.15 - 0.1 * c;
        break;
      }
      case 'sleep':
        T.brx = -Math.PI / 2; T.by = (o.bedH ?? 0.6) + 0.2 * s;
        T.aLz = 0.15; T.aRz = -0.15; T.eL = T.eR = 0;
        T.hz = (o.lean || 0) * 0.6;
        break;
      case 'leanHead': {
        // Head resting on the partner's shoulder; `side` is where the partner is.
        const sd = o.side ?? 1;
        if (o.seatH !== undefined) sit(o.seatH);
        T.tz = -sd * 0.26;
        T.hz = -sd * 0.44;
        T.hx = 0.1 + Math.sin(t * 0.9) * 0.02;
        T[sd > 0 ? 'aLz' : 'aRz'] = sd * 0.3;
        T[sd > 0 ? 'eL' : 'eR'] = -0.5;
        break;
      }
      case 'lapSit': {
        const h = (o.seatH ?? 0.47) + 0.26;
        T.thL = -Math.PI / 2 + 0.14; T.thR = -Math.PI / 2 + 0.08;
        T.shL = Math.PI / 2 - 0.3; T.shR = Math.PI / 2 - 0.22;
        T.by = h - HIP_Y * s;
        const sd = o.side ?? 1;
        T.aLx = T.aRx = -0.25; T.aLz = 0.34; T.aRz = -0.34; T.eL = T.eR = -0.55;
        T.tx = -0.04 + Math.sin(t * 1.1) * 0.015; T.tz = -sd * 0.2; T.sk = -0.75;
        T.hz = -sd * 0.3; T.hx = -0.06;
        // Arm up and around his shoulders.
        if (sd > 0) { T.aLz = 1.25; T.aLx = -0.35; T.eL = -1.3; }
        else { T.aRz = -1.25; T.aRx = -0.35; T.eR = -1.3; }
        break;
      }
      case 'headLap': {
        T.brx = -Math.PI / 2; T.by = (o.bedH ?? 0.47) + 0.2 * s;
        T.thL = -0.32; T.thR = -0.5; T.shL = 0.7; T.shR = 0.95;
        T.aLz = -0.4; T.aRz = 0.4; T.eL = T.eR = -1.15;
        T.sk = -0.45;
        T.hx = Math.sin(t * 0.8) * 0.03;
        break;
      }
      case 'kiss':
        T.aLx = T.aRx = -1.25; T.aLz = -0.55; T.aRz = 0.55; T.eL = T.eR = -1.0;
        T.tx = 0.14 + Math.sin(t * 1.6) * 0.03;
        T.hx = -0.1; T.hz = this.female ? 0.16 : -0.16;
        T.by = this.female ? 0.04 : 0;
        break;
      case 'snuggle': {
        // Lying down, rolled over to face the partner at local `side`.
        const sd = o.side ?? 1;
        T.brx = -Math.PI / 2; T.bry = sd * 1.0; T.by = (o.bedH ?? 0.6) + 0.2 * s;
        T.thL = -0.26; T.thR = -0.12; T.shL = 0.5; T.shR = 0.22;
        T.aLx = T.aRx = -0.5; T.aLz = -0.3; T.aRz = 0.3; T.eL = T.eR = -1.2;
        T.hz = -sd * 0.12;
        break;
      }
      case 'talk': {
        if (o.speaking) {
          T.aRx = -0.7 + Math.sin(t * 5) * 0.25; T.eR = -1.0; T.aRz = -0.2;
          T.aLx = -0.3 + Math.sin(t * 4 + 1) * 0.15; T.eL = -0.6;
          T.hx = Math.sin(t * 6) * 0.06;
        } else {
          T.hz = 0.12 + Math.sin(t * 1.3) * 0.05; T.hx = Math.sin(t * 2) * 0.08;
        }
        break;
      }
      case 'wave':
        T.aRz = -2.6 + Math.sin(t * 9) * 0.35; T.eR = -0.3; T.hz = 0.1;
        break;
      case 'hug':
        T.aLx = T.aRx = -1.35; T.aLz = -0.45; T.aRz = 0.45; T.eL = T.eR = -0.9; T.hz = this.female ? 0.25 : -0.15; T.tx = 0.1;
        break;
      case 'dance': {
        const b = Math.abs(Math.sin(t * 5));
        T.by = b * 0.1;
        T.bry = Math.sin(t * 2.5) * 0.6;
        T.aLz = 2.3 + Math.sin(t * 5) * 0.5; T.aRz = -2.3 + Math.sin(t * 5 + Math.PI) * 0.5;
        T.eL = T.eR = -0.5;
        T.thL = Math.sin(t * 5) * 0.3; T.thR = -T.thL; T.shL = T.shR = 0.3 * b;
        T.hz = Math.sin(t * 5) * 0.15;
        break;
      }
    }
    if (o.arm) armTo(o.arm, o.side ?? 1);
    const C = this.cur;
    for (const k of POSE_KEYS) C[k] = damp(C[k], T[k], this.pose === 'walk' ? 18 : 9, dt);

    this.legs[0].thigh.rotation.x = C.thR; this.legs[0].knee.rotation.x = C.shR;
    this.legs[1].thigh.rotation.x = C.thL; this.legs[1].knee.rotation.x = C.shL;
    this.arms[0].sh.rotation.set(C.aRx, 0, C.aRz); this.arms[0].el.rotation.x = C.eR;
    this.arms[1].sh.rotation.set(C.aLx, 0, C.aLz); this.arms[1].el.rotation.x = C.eL;
    this.body.position.y = C.by;
    this.body.rotation.set(C.brx, C.bry, 0);
    this.torso.rotation.x = C.tx;
    this.torso.rotation.z = C.tz;
    this.head.rotation.set(C.hx, 0, C.hz);
    this.skirtPivot.rotation.x = C.sk;
    if (this.skirtLen) this.skirt.scale.y = this.skirtLen * (1 + C.sk * 0.45);
    if (this.skirtLen) this.skirt.position.y = -this.skirt.scale.y / 2;
  }
}
