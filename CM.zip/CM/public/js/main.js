import * as THREE from 'three';
import { clamp, damp, dampAngle, resolveCircle } from './utils.js';
import { Sky } from './sky.js';
import { buildWorld } from './world.js';
import { Character, inHouse } from './character.js';
import { Car } from './car.js';
import { Photos } from './photos.js';
import { Activities } from './activities.js';
import { ui, Minimap, Hearts } from './ui.js';
import { Net } from './net.js';

const $ = id => document.getElementById(id);
const params = new URLSearchParams(location.search);
const SAVE_KEY = 'our-little-world-save';
const load = () => { try { return JSON.parse(localStorage.getItem(SAVE_KEY)) || {}; } catch { return {}; } };
const saved = load();
// Each browser owns one character. Older saves stored both, so read those too.
const profile = {
  me: saved.me ?? 0,
  name: saved.name ?? saved.names?.[saved.me ?? 0],
  outfit: saved.outfit ?? saved.outfits?.[saved.me ?? 0] ?? 0,
  hair: typeof saved.hair === 'string' ? saved.hair : saved.hair?.[saved.me ?? 0],
};

// ---------- Renderer / scene ----------
const canvas = $('game');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 1200);
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

const sky = new Sky(scene);
const world = buildWorld(scene);
const car = new Car(scene);
const hearts = new Hearts(scene);
const minimap = new Minimap(world);
const photos = new Photos(world.frames, t => ui.toast(t));

const DEFAULT_NAMES = ['Leo', 'Mia'];
const chars = [
  new Character({ gender: 'male', name: DEFAULT_NAMES[0] }),
  new Character({ gender: 'female', name: DEFAULT_NAMES[1] }),
];
const SPAWN = new THREE.Vector3(0, 0, -1.5);
chars.forEach(c => {
  c.pos.copy(SPAWN);
  c.yaw = 0;
  c.mode = 'hidden';
  c.root.visible = false;
  scene.add(c.root);
});

// ---------- Game state ----------
const net = new Net();
// Multiplayer: the host (whoever invited) owns time, the house and activities; each side moves its own character.
const mp = { on: false, host: false, owned: false, riding: false, remoteAct: null, sendT: 0, endAsked: false };
const isGuest = () => mp.on && !mp.host;

const game = {
  chars, world, car, hearts, sky,
  active: profile.me,
  hours: saved.hours ?? 16.5,
  day: saved.day ?? 1,
  speedIdx: 0,
  warp: null,
  driving: false,
  started: false,
  get player() { return chars[this.active]; },
  get partner() { return chars[1 - this.active]; },
  warpTo(h) { this.warp = h; },
  setTime(h, nextDay) {
    if (nextDay && h <= this.hours) this.day++;
    this.hours = h;
    this.warp = null;
  },
  // Hands a character back after an activity: to this player, or to the friend's browser.
  release(c) {
    if (c === this.player) { c.mode = 'player'; return; }
    if (mp.on) {
      c.mode = 'remote';
      c.setNet(c.netState());
      net.send({ t: 'own', take: false, s: c.netState() });
      return;
    }
    c.mode = 'hidden';
    c.root.visible = false;
  },
};

// One activity slot per character, so both can do their own thing at the same time.
const acts = chars.map(() => new Activities(game));
const actOf = c => acts.find(a => a.cur?.participants.includes(c)) || null;

// Toasts and fades only show for the people in the activity; bubbles and hearts show for everyone.
acts.forEach(A => {
  const base = { ...A.fx };
  const involves = c => A.lead === c || A.other === c;
  A.fx = {
    say: (c, text, dur) => { base.say(c, text, dur); net.send({ t: 'fx', k: 'say', i: chars.indexOf(c), text, dur }); },
    hearts: (p, n) => { base.hearts(p, n); net.send({ t: 'fx', k: 'hearts', p: p.toArray(), n }); },
    toast: text => {
      if (involves(game.player)) base.toast(text);
      if (involves(game.partner)) net.send({ t: 'fx', k: 'toast', text });
    },
    fade: on => {
      if (involves(game.player)) base.fade(on);
      if (involves(game.partner)) net.send({ t: 'fx', k: 'fade', on });
    },
  };
});

const SPEEDS = [1, 6, 0];
const HOURS_PER_SEC = 1 / 30;

function save() {
  const p = game.player;
  const data = load();
  delete data.names;
  delete data.outfits;
  data.name = p.name;
  if (!isGuest()) Object.assign(data, { me: game.active, hours: game.hours, day: game.day });
  if (!isGuest() || game.active === data.me) Object.assign(data, { outfit: p.outfitIndex, hair: p.hairColor });
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(data)); } catch { /* storage unavailable */ }
}
setInterval(() => game.started && save(), 5000);
addEventListener('beforeunload', () => game.started && save());

// ---------- Input ----------
const keys = new Set();
const OVERLAYS = ['wardrobe', 'helpPanel', 'lightbox', 'menuPanel'];
const overlayOpen = () => OVERLAYS.some(id => !$(id).classList.contains('hidden'));

addEventListener('keydown', e => {
  if (e.target.tagName === 'INPUT') {
    if (e.code !== 'Enter') return;
    if (!$('menuPanel').classList.contains('hidden')) saveName();
    else if (!game.started) (invited ? $('joinBtn') : $('startBtn')).click();
    return;
  }
  if (['Tab', 'Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
  if (e.code === 'Escape') {
    if (overlayOpen()) closeOverlays();
    else if (game.started) openMenu();
    return;
  }
  if (!game.started || overlayOpen()) return;
  keys.add(e.code);
  if (!e.repeat) onAction(e.code);
});
addEventListener('keyup', e => keys.delete(e.code));
addEventListener('blur', () => keys.clear());

function readInput() {
  const k = c => keys.has(c);
  return {
    x: (k('KeyD') || k('ArrowRight') ? 1 : 0) - (k('KeyA') || k('ArrowLeft') ? 1 : 0),
    z: (k('KeyW') || k('ArrowUp') ? 1 : 0) - (k('KeyS') || k('ArrowDown') ? 1 : 0),
    run: k('ShiftLeft') || k('ShiftRight'),
    jump: k('Space'),
  };
}

function closeOverlays() {
  for (const id of OVERLAYS) $(id).classList.add('hidden');
  photos.hideMenu();
}
document.querySelectorAll('.closeBtn').forEach(b => b.addEventListener('click', closeOverlays));

function openMenu() {
  $('mName').value = game.player.name;
  updateMpUI();
  $('menuPanel').classList.remove('hidden');
}
function saveName() {
  const name = $('mName').value.trim();
  if (!name) return;
  game.player.name = name;
  $('playingName').textContent = name;
  save();
  net.send({ t: 'name', i: game.active, name });
  updateMpUI();
  ui.toast(`Hi, ${name}!`);
}
$('menuBtn').addEventListener('click', openMenu);
$('menuSave').addEventListener('click', saveName);
$('menuHelp').addEventListener('click', () => {
  $('menuPanel').classList.add('hidden');
  $('helpPanel').classList.remove('hidden');
});
$('menuWardrobe').addEventListener('click', () => {
  $('menuPanel').classList.add('hidden');
  openWardrobe();
});

// ---------- Audio (horn) ----------
let audio;
function horn() {
  audio ||= new AudioContext();
  const t = audio.currentTime;
  for (const f of [392, 494]) {
    const o = audio.createOscillator(), gn = audio.createGain();
    o.type = 'square'; o.frequency.value = f;
    gn.gain.setValueAtTime(0.06, t); gn.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
    o.connect(gn).connect(audio.destination);
    o.start(t); o.stop(t + 0.5);
  }
}

// ---------- Interactions ----------
function nearestSpot() {
  const p = game.player.pos;
  let best = null, bestD = Infinity;
  for (const [id, s] of Object.entries(world.spots)) {
    const d = Math.hypot(p.x - s.center.x, p.z - s.center.z);
    if (d < s.radius && d < bestD) { best = id; bestD = d; }
  }
  const dc = Math.hypot(p.x - car.pos.x, p.z - car.pos.z);
  if (dc < 3.4 && dc < bestD) best = 'car';
  return best;
}

const night = () => game.hours >= 19.5 || game.hours < 5.5;
const partnerNear = (d = 20) => mp.on && game.partner.root.visible && game.player.pos.distanceTo(game.partner.pos) < d;
const LABELS = {
  bench: () => (night() ? 'Stargaze on the bench' : 'Sit on the bench & watch the sunset'),
  bed: () => (partnerNear() ? 'Go to sleep together' : 'Go to sleep'),
  sofa: () => (partnerNear() ? 'Cuddle on the sofa & watch TV' : 'Watch TV on the sofa'),
  homeTable: () => 'Have dinner at home',
  cafeTable: () => (partnerNear() ? 'Date night at Café Amour' : 'Eat at Café Amour'),
  wardrobe: () => 'Change clothes',
  car: () => (car.owner !== null && car.owner !== game.active ? `Ride with ${chars[car.owner].name}` : 'Drive the car'),
};

const PAIR_KINDS = { KeyT: 'talk', KeyG: 'hug', KeyF: 'dance', KeyK: 'kiss', KeyC: 'lean', KeyZ: 'holdHands' };
const PAIR_REACH = { talk: 15, hug: 15, kiss: 15, lean: 15, holdHands: 15, dance: 25 };

// Can this character be pulled into something right now? (host side)
function available(c) {
  if (!c.root.visible || actOf(c)) return false;
  return c === game.player ? c.mode === 'player' && !game.driving && !mp.riding : mp.on && c.mode === 'remote';
}

function startActivity(kind, lead, partner = null) {
  const A = acts[chars.indexOf(lead)];
  A.start(kind, lead, partner);
  if (mp.on && A.cur?.participants.includes(game.partner)) net.send({ t: 'own', take: true });
}

// A seat (bench, bed, sofa, table): together if the other one is close and free, otherwise alone.
function startSpot(kind, lead) {
  const other = chars.find(c => c !== lead);
  const theirs = actOf(other);
  if (theirs && theirs.cur.kind === kind && theirs.cur.participants.length === 1) {
    theirs.end(true); // they were sitting there alone: join them
    return startActivity(kind, lead, other);
  }
  const together = available(other) && lead.pos.distanceTo(other.pos) < 20;
  startActivity(kind, lead, together ? other : null);
}

// Talk, hug, kiss...: these need the two of you.
function startPair(kind, lead) {
  const other = chars.find(c => c !== lead);
  if (!available(other)) return `${other.name} is busy right now`;
  if (lead.pos.distanceTo(other.pos) > PAIR_REACH[kind]) return `${other.name} is too far away. Walk closer!`;
  startActivity(kind, lead, other);
  return null;
}

const ALONE_MSG = 'You need someone for that. Invite a friend from the menu (Esc)!';

function onAction(code) {
  const p = game.player;
  if (mp.riding) {
    if (code === 'KeyE') exitRide();
    return;
  }
  if (game.driving) {
    if (code === 'KeyE') exitCar();
    if (code === 'KeyH') { horn(); net.send({ t: 'horn' }); }
    return;
  }
  if (isGuest() && mp.owned) {
    if (code === 'KeyE') net.send({ t: 'req', k: 'end' });
    if (code === 'KeyC') net.send({ t: 'req', k: 'cuddle' });
    return;
  }
  const mine = actOf(p);
  if (mine) {
    if (code === 'KeyC' && !mine.cycleCuddle()) ui.toast(mine.other ? 'Nothing to cuddle into here' : ALONE_MSG);
    if (code === 'KeyE') mine.end();
    return;
  }
  if (p.mode !== 'player') return;
  switch (code) {
    case 'KeyE': {
      const s = nearestSpot();
      if (!s) return;
      if (s === 'car') return enterCar();
      if (s === 'wardrobe') {
        p.yaw = -Math.PI / 2;
        p.setPose('idle');
        openWardrobe();
        return;
      }
      if (isGuest()) net.send({ t: 'req', k: 'start', kind: s });
      else startSpot(s, p);
      return;
    }
    case 'KeyT':
    case 'KeyG':
    case 'KeyF':
    case 'KeyK':
    case 'KeyC':
    case 'KeyZ': {
      const kind = PAIR_KINDS[code];
      const near = partnerNear(PAIR_REACH[kind]);
      if (!near) {
        if (kind === 'dance') { p.mode = 'busy'; p.setPose('dance'); soloDance = true; return; }
        ui.toast(mp.on ? `${game.partner.name} is too far away. Walk closer!` : ALONE_MSG);
        return;
      }
      if (isGuest()) { net.send({ t: 'req', k: 'start', kind }); return; }
      const err = startPair(kind, p);
      if (err) ui.toast(err);
      return;
    }
    case 'KeyQ':
      p.setPose('wave');
      waveT = 2;
      return;
  }
}
let waveT = 0, soloDance = false;

function openWardrobe() {
  ui.openWardrobe([game.player], 0, () => {
    save();
    net.send({ t: 'look', i: game.active, o: game.player.outfitIndex, h: game.player.hairColor });
  });
}

// ---------- Car ----------
function enterCar() {
  const p = game.player;
  if (car.owner !== null && car.owner !== game.active) { startRide(); return; }
  game.driving = true;
  car.owner = game.active;
  p.mode = 'hidden';
  p.root.visible = false;
  net.send({ t: 'car', owner: game.active, s: car.netState() });
  $('speedo').classList.remove('hidden');
}

function placeBesideCar(ch, side) {
  const f = car.forward(), right = new THREE.Vector3(-f.z, 0, f.x);
  ch.pos.copy(car.pos).addScaledVector(right, side * 1.9);
  ch.pos.y = 0;
  resolveCircle(ch.pos, 0.35, world.colliders.concat(car.colliders()));
  ch.yaw = car.yaw;
  ch.root.visible = true;
}

function exitCar() {
  if (Math.abs(car.speed) > 3) { ui.toast('Slow down first!'); return; }
  const p = game.player;
  placeBesideCar(p, -1);
  p.mode = 'player';
  game.driving = false;
  car.speed = 0;
  car.owner = null;
  net.send({ t: 'car', owner: null, s: car.netState() });
  $('speedo').classList.add('hidden');
}

function startRide() {
  const p = game.player;
  mp.riding = true;
  p.mode = 'hidden';
  p.root.visible = false;
  $('speedo').classList.remove('hidden');
  ui.toast(`Riding with ${chars[car.owner].name}`);
}

function exitRide() {
  const p = game.player;
  placeBesideCar(p, 1);
  p.mode = 'player';
  p.setPose('idle');
  mp.riding = false;
  $('speedo').classList.add('hidden');
}

// ---------- Camera ----------
const cam = { yaw: 0.4, pitch: 0.3, dist: 9, target: new THREE.Vector3(), pos: new THREE.Vector3(0, 5, 8), look: new THREE.Vector3(), lastDrag: -10 };
let drag = null;
const raycaster = new THREE.Raycaster();
const ndc = new THREE.Vector2();

canvas.addEventListener('pointerdown', e => {
  drag = { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY };
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener('pointermove', e => {
  if (drag) {
    cam.yaw -= (e.clientX - drag.x) * 0.006;
    cam.pitch = clamp(cam.pitch + (e.clientY - drag.y) * 0.004, -0.5, 1.45);
    drag.x = e.clientX; drag.y = e.clientY;
    if (Math.hypot(e.clientX - drag.sx, e.clientY - drag.sy) > 6) cam.lastDrag = clock.elapsedTime;
    return;
  }
  canvas.style.cursor = pickFrame(e) ? 'pointer' : 'grab';
});
canvas.addEventListener('pointerup', e => {
  const moved = drag ? Math.hypot(e.clientX - drag.sx, e.clientY - drag.sy) : 99;
  drag = null;
  if (moved < 6 && game.started) {
    const f = pickFrame(e);
    if (f) photos.click(f, e.clientX, e.clientY);
  }
});
canvas.addEventListener('wheel', e => {
  cam.dist = clamp(cam.dist * (1 + e.deltaY * 0.001), 2.5, 22);
}, { passive: true });

function pickFrame(e) {
  ndc.set((e.clientX / innerWidth) * 2 - 1, -(e.clientY / innerHeight) * 2 + 1);
  raycaster.setFromCamera(ndc, camera);
  const blockers = world.occluders.filter(o => (o.userData.opacity ?? 1) > 0.5);
  if (world.roof.visible) blockers.push(world.roof);
  const hit = raycaster.intersectObjects([...photos.meshes, ...blockers], true)[0];
  return hit && hit.distance < 25 ? hit.object.userData.frame : null;
}

const occluderSet = new Set(world.occluders);
function fadeOccluders(dt, from, to) {
  const dir = to.clone().sub(from);
  const len = dir.length();
  raycaster.set(from, dir.normalize());
  raycaster.far = len - 0.3;
  const hits = new Set();
  for (const h of raycaster.intersectObjects(world.occluders, true)) {
    let o = h.object;
    while (o && !occluderSet.has(o)) o = o.parent;
    if (o) hits.add(o);
  }
  raycaster.far = Infinity;
  for (const o of world.occluders) {
    const cur = o.userData.opacity ?? 1;
    const next = damp(cur, hits.has(o) ? 0.12 : 1, 10, dt);
    if (Math.abs(next - cur) < 0.001) continue;
    o.userData.opacity = next;
    o.traverse(m => { if (m.isMesh && m.material.transparent) m.material.opacity = next; });
  }
}

// Pull the camera in when furniture sits between it and the character.
const camRay = new THREE.Raycaster();
function fitIndoorCamera(desired) {
  const dir = desired.clone().sub(cam.target);
  const len = dir.length();
  if (len < 0.5) return;
  camRay.set(cam.target, dir.divideScalar(len));
  camRay.far = len;
  const hit = camRay.intersectObjects(world.interior, true)[0];
  camRay.far = Infinity;
  if (hit) desired.copy(cam.target).addScaledVector(dir, Math.max(1.1, hit.distance - 0.25));
}

const cineA = new THREE.Vector3(), cineB = new THREE.Vector3();
function currentCinematic() {
  const a = actOf(game.player)?.cur;
  if (a) return a.phase === 'active' && a.camera;
  const r = isGuest() && mp.owned ? mp.remoteAct : null;
  if (r?.ph === 'active' && r.cam) return { pos: cineA.fromArray(r.cam[0]), look: cineB.fromArray(r.cam[1]) };
  return null;
}

function updateCamera(dt) {
  const inCar = game.driving || mp.riding;
  const focus = inCar ? car.pos : game.player.pos;
  const indoor = !inCar && inHouse(focus);
  world.roof.visible = !indoor;
  cam.target.set(focus.x, (inCar ? 1.2 : Math.max(focus.y, 0)) + 1.4, focus.z);

  if (inCar && clock.elapsedTime - cam.lastDrag > 1.5 && Math.abs(car.speed) > 1) {
    cam.yaw = dampAngle(cam.yaw, car.yaw + (car.speed < 0 ? 0 : Math.PI), 2.5, dt);
    cam.pitch = damp(cam.pitch, 0.28, 1.5, dt);
  }
  const dist = inCar ? Math.max(cam.dist, 8) : indoor ? Math.min(cam.dist, 8) : cam.dist;
  const pitch = cam.pitch;
  const desired = new THREE.Vector3(
    cam.target.x + Math.sin(cam.yaw) * Math.cos(pitch) * dist,
    cam.target.y + Math.sin(pitch) * dist,
    cam.target.z + Math.cos(cam.yaw) * Math.cos(pitch) * dist,
  );
  // Indoors, an eye-level camera stays inside the room instead of sliding behind a wall.
  if (indoor) {
    if (desired.y < 3.1) {
      desired.x = clamp(desired.x, -7.5, 7.5);
      desired.z = clamp(desired.z, -15.5, -4.5);
    }
    fitIndoorCamera(desired);
  }
  let look = cam.target, rate = 14;
  const cine = currentCinematic();
  if (cine && clock.elapsedTime - cam.lastDrag > 3) { desired.copy(cine.pos); look = cine.look; rate = 2; }
  desired.y = Math.max(desired.y, 0.4);
  cam.pos.lerp(desired, 1 - Math.exp(-rate * dt));
  cam.look.lerp(look, 1 - Math.exp(-rate * dt));
  camera.position.copy(cam.pos);
  camera.lookAt(cam.look);
  fadeOccluders(dt, cam.pos, cam.target);
}

// ---------- HUD ----------
const fmtTime = h => `${String(Math.floor(h)).padStart(2, '0')}:${String(Math.floor((h % 1) * 60)).padStart(2, '0')}`;
function updateSpeedBtn() {
  $('speedBtn').textContent = SPEEDS[game.speedIdx] ? `Time ${SPEEDS[game.speedIdx]}x` : 'Time paused';
}
function cycleSpeed() {
  game.speedIdx = (game.speedIdx + 1) % SPEEDS.length;
  updateSpeedBtn();
}
$('speedBtn').addEventListener('click', () => (isGuest() ? net.send({ t: 'req', k: 'speed' }) : cycleSpeed()));
$('helpBtn').addEventListener('click', () => $('helpPanel').classList.remove('hidden'));

// What the activity prompt shows for an activity, wherever it runs.
function actInfo(A) {
  const a = A.cur;
  return { ph: a.phase, st: a.stand || (a.standUp ? 'Stand up' : 'Stop'), nx: A.nextCuddleName(), who: A.other && A.other !== game.player ? A.other.name : null };
}

function updateHUD() {
  $('clock').textContent = fmtTime(game.hours);
  $('day').textContent = `Day ${game.day}${game.warp !== null ? ' · time flying...' : ''}`;
  const mine = actOf(game.player);
  const act = mine ? actInfo(mine) : isGuest() && mp.owned ? mp.remoteAct : null;
  if (mp.riding) {
    ui.prompt('<kbd>E</kbd> Get out');
    ui.hints('');
    $('speedVal').textContent = Math.round(Math.abs(car.speed) * 3.6);
  } else if (game.driving) {
    ui.prompt(Math.abs(car.speed) < 3 ? '<kbd>E</kbd> Get out' : '');
    ui.hints('W/S gas & reverse · A/D steer · Space brake · Shift boost · H horn');
    $('speedVal').textContent = Math.round(Math.abs(car.speed) * 3.6);
  } else if (act || (isGuest() && mp.owned)) {
    if (!act || act.ph === 'gather') {
      ui.prompt(act?.who ? `${act.who} is coming...` : 'Getting comfy...');
    } else {
      const stop = `<kbd>E</kbd> ${act.st}`;
      ui.prompt(act.nx ? `${stop} &nbsp; <kbd>C</kbd> ${act.nx}` : stop);
    }
    ui.hints('');
  } else if (game.player.mode === 'player') {
    const s = nearestSpot();
    ui.prompt(s ? `<kbd>E</kbd> ${LABELS[s]()}` : '');
    ui.hints(mp.on
      ? 'E interact · T talk · G hug · K kiss · C cuddle · Z hold hands · F dance · Q wave · Esc menu'
      : 'E interact · F dance · Q wave · Esc menu to invite a friend · Click frames to add photos');
  } else {
    ui.prompt(soloDance ? '<kbd>W A S D</kbd> Stop dancing' : '');
  }
}

// ---------- Start screen ----------
const invitedCode = (params.get('join') || '').trim().toUpperCase();
let invited = invitedCode.length === 6;
let chosen = profile.me;

function showPreview() {
  chars.forEach((c, i) => {
    c.root.visible = i === chosen;
    c.mode = i === chosen ? 'busy' : 'hidden';
    c.pos.copy(SPAWN);
    c.yaw = 0;
    c.setPose('idle');
  });
  document.querySelectorAll('.who').forEach(b => b.classList.toggle('selected', Number(b.dataset.me) === chosen));
}

function applyProfile(i) {
  const c = chars[i];
  if (i === profile.me) {
    c.setOutfit(profile.outfit);
    if (profile.hair) c.setHair(profile.hair);
  }
}
applyProfile(profile.me);
$('myName').value = profile.name || '';
document.querySelectorAll('.who').forEach(b => b.addEventListener('click', () => {
  chosen = Number(b.dataset.me);
  applyProfile(chosen);
  showPreview();
}));

function enterWorld() {
  game.active = chosen;
  const p = game.player;
  p.name = $('myName').value.trim() || p.name || DEFAULT_NAMES[chosen];
  game.partner.mode = 'hidden';
  game.partner.root.visible = false;
  p.mode = 'player';
  p.root.visible = true;
  p.popIn();
  $('startScreen').classList.add('hidden');
  $('hud').classList.remove('hidden');
  $('playingName').textContent = p.name;
  game.started = true;
  save();
  updateMpUI();
}
$('startBtn').addEventListener('click', () => {
  enterWorld();
  ui.toast(`Welcome home, ${game.player.name}`);
});

if (invited) {
  $('startScreen').classList.add('invited');
  $('joinCode').value = invitedCode;
  $('joinBtn').classList.add('primary');
} else {
  showPreview();
}
$('playAlone').addEventListener('click', e => {
  e.preventDefault();
  invited = false;
  history.replaceState(null, '', location.pathname);
  $('startScreen').classList.remove('invited');
  $('joinBtn').classList.remove('primary');
  showPreview();
});

// ---------- Multiplayer ----------
const tell = text => net.send({ t: 'toast', text });

async function blobToB64(blob) {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
const b64ToBlob = s => (s ? new Blob([Uint8Array.from(atob(s), ch => ch.charCodeAt(0))], { type: 'image/jpeg' }) : null);

photos.onChange = async (id, blob) => {
  if (mp.on && mp.host) net.send({ t: 'photo', id, img: blob ? await blobToB64(blob) : null });
};

const worldState = () => ({
  h: game.hours, d: game.day, warp: game.warp, sp: game.speedIdx,
  tv: world.tv.on, hf: world.homeFood.level, cf: world.cafeFood.level, bl: world.blanket.position.y,
});

function applyWorld(w) {
  game.hours = w.h;
  game.day = w.d;
  game.warp = w.warp ?? null;
  if (game.speedIdx !== w.sp) { game.speedIdx = w.sp; updateSpeedBtn(); }
  if (world.tv.on !== w.tv) world.tv.setOn(w.tv);
  if (world.homeFood.level !== w.hf) world.homeFood.set(w.hf);
  if (world.cafeFood.level !== w.cf) world.cafeFood.set(w.cf);
  world.blanket.position.y = w.bl;
}

function setLook(c, outfit, hair) {
  if (c.outfitIndex !== outfit) c.setOutfit(outfit);
  if (hair && c.hairColor !== hair) c.setHair(hair);
}

function netTick(dt) {
  if (!mp.on) return;
  if ((mp.sendT += dt) < 1 / 15) return;
  mp.sendT = 0;
  const msg = { t: 's', c: {} };
  if (!mp.owned) msg.c[game.active] = game.player.netState();
  if (mp.host && game.partner.mode !== 'remote') msg.c[1 - game.active] = game.partner.netState();
  if (game.driving) msg.car = car.netState();
  if (mp.host) {
    msg.w = worldState();
    const theirs = actOf(game.partner);
    if (theirs) {
      const a = theirs.cur;
      msg.act = {
        ...actInfo(theirs),
        who: theirs.other && theirs.other !== game.partner ? theirs.other.name : null,
        cam: a.camera ? [a.camera.pos.toArray(), a.camera.look.toArray()] : null,
      };
    }
  }
  net.send(msg);
}

function onNetMessage(m) {
  switch (m.t) {
    case 'hello': if (mp.host || net.role === 'host') welcomeGuest(m); return;
    case 'welcome': enterAsGuest(m); return;
    case 's': applySync(m); return;
    case 'fx':
      if (m.k === 'say') ui.say(chars[m.i], m.text, m.dur);
      else if (m.k === 'toast') ui.toast(m.text);
      else if (m.k === 'fade') ui.fade(m.on);
      else if (m.k === 'hearts') hearts.burst(new THREE.Vector3().fromArray(m.p), m.n);
      return;
    case 'own': applyOwn(m); return;
    case 'req': if (mp.host) handleReq(m); return;
    case 'toast': ui.toast(m.text); return;
    case 'look': setLook(chars[m.i], m.o, m.h); return;
    case 'name':
      chars[m.i].name = m.name;
      updateMpUI();
      return;
    case 'car':
      car.owner = m.owner;
      if (m.s) car.setNet(m.s, m.owner === null);
      if (m.owner === null) { car.speed = 0; if (mp.riding) exitRide(); }
      return;
    case 'horn': horn(); return;
    case 'photo': if (isGuest()) photos.display(m.id, b64ToBlob(m.img)); return;
    case 'bye': onPeerLost(); return;
  }
}

function applySync(m) {
  for (const [i, st] of Object.entries(m.c || {})) {
    const c = chars[i];
    if (c?.mode === 'remote') c.setNet(st);
  }
  if (m.car && car.owner !== null && car.owner !== game.active) car.setNet(m.car);
  if (isGuest()) {
    if (m.w) applyWorld(m.w);
    mp.remoteAct = m.act || null;
  }
}

// Guest side: the host takes over our character for an activity, then hands it back.
function applyOwn(m) {
  const p = game.player;
  if (m.take) {
    mp.owned = true;
    mp.endAsked = false;
    soloDance = false;
    closeOverlays();
    p.setNet(p.netState());
    p.mode = 'remote';
  } else {
    mp.owned = false;
    mp.remoteAct = null;
    if (m.s) { p.pos.fromArray(m.s.p); p.yaw = m.s.y; }
    p.mode = 'player';
    p.root.visible = true;
    p.setPose('idle');
  }
}

// Host side: the friend asked for something.
function handleReq(m) {
  const g = game.partner;
  if (g.net) g.pos.copy(g.net.pos);
  switch (m.k) {
    case 'start': {
      if (actOf(g) || g.mode !== 'remote' || !g.root.visible) return;
      if (PAIR_REACH[m.kind]) {
        const err = startPair(m.kind, g);
        if (err) tell(err);
      } else if (world.spots[m.kind]) {
        startSpot(m.kind, g);
      }
      return;
    }
    case 'end': actOf(g)?.end(); return;
    case 'cuddle': {
      const A = actOf(g);
      if (A && !A.cycleCuddle()) tell(A.other ? 'Nothing to cuddle into here' : ALONE_MSG);
      return;
    }
    case 'speed': cycleSpeed(); return;
    case 'photo': photos.store(m.id, b64ToBlob(m.img)); return;
  }
}

// Host side: the friend arrived. Their character pops in right next to us.
async function welcomeGuest(hello) {
  const p = game.player, o = game.partner;
  mp.on = true;
  mp.host = true;
  o.name = (hello.name || '').trim().slice(0, 14) || DEFAULT_NAMES[1 - game.active];
  const look = hello.look?.me === 1 - game.active ? hello.look : null;
  o.setOutfit(look?.outfit ?? 0);
  if (hello.look?.hair) o.setHair(hello.look.hair);
  const base = game.driving ? car.pos : p.pos;
  const yaw = game.driving ? car.yaw : p.yaw;
  const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
  o.pos.copy(base).addScaledVector(right, game.driving ? 2.4 : 1.2).setY(0);
  resolveCircle(o.pos, 0.35, world.colliders.concat(car.colliders()));
  o.yaw = yaw;
  o.root.visible = true;
  o.setPose('idle');
  o.setNet(o.netState());
  o.mode = 'remote';
  o.popIn();
  net.send({
    t: 'welcome', you: 1 - game.active,
    names: chars.map(c => c.name),
    looks: chars.map(c => [c.outfitIndex, c.hairColor]),
    c: { 0: chars[0].netState(), 1: chars[1].netState() },
    w: worldState(),
    car: { owner: car.owner, s: car.netState() },
  });
  hearts.burst(o.pos.clone().setY(1.8), 10);
  ui.toast(`${o.name} is online!`);
  updateMpUI();
  for (const f of world.frames) if (f.blob) net.send({ t: 'photo', id: f.id, img: await blobToB64(f.blob) });
}

// Guest side: step into the host's world.
function enterAsGuest(m) {
  mp.on = true;
  mp.host = false;
  game.active = m.you;
  chars.forEach((c, i) => {
    c.name = m.names[i];
    setLook(c, m.looks[i][0], m.looks[i][1]);
  });
  const p = game.player, o = game.partner;
  const mine = m.c[m.you];
  p.pos.fromArray(mine.p);
  p.yaw = mine.y;
  p.root.visible = true;
  p.mode = 'player';
  p.setPose('idle');
  p.popIn();
  o.root.visible = true;
  o.setNet(m.c[1 - m.you]);
  o.mode = 'remote';
  applyWorld(m.w);
  car.owner = m.car.owner;
  car.setNet(m.car.s, true);
  photos.remoteSave = async (id, blob) => net.send({ t: 'req', k: 'photo', id, img: blob ? await blobToB64(blob) : null });
  photos.clearDisplay();
  $('startScreen').classList.add('hidden');
  $('hud').classList.remove('hidden');
  $('playingName').textContent = p.name;
  game.started = true;
  hearts.burst(p.pos.clone().setY(1.8), 10);
  ui.toast(`You're in ${o.name}'s world!`);
  save();
  updateMpUI();
}

function onPeerLost() {
  if (!mp.on) return;
  const o = game.partner;
  if (!mp.host) {
    mp.on = false;
    ui.toast(`${o.name} went offline. Taking you home...`);
    net.destroy();
    setTimeout(() => { location.href = location.pathname; }, 2500);
    return;
  }
  mp.on = false;
  hearts.burst(o.pos.clone().setY(1.6), 6);
  o.root.visible = false;
  actOf(o)?.end();
  o.mode = 'hidden';
  if (car.owner === 1 - game.active) { car.owner = null; car.speed = 0; }
  net.kick();
  ui.toast(`${o.name} went offline. They can come back with the same link.`);
  updateMpUI();
}

net.on('message', onNetMessage).on('close', onPeerLost).on('ended', () => {
  if (!game.started) return;
  ui.toast('Lost the connection to the game server. Make a new invite from the menu.');
  updateMpUI();
});
addEventListener('pagehide', () => net.send({ t: 'bye' }));

// ----- Invite / join UI -----
const inviteLink = () => `${location.origin}${location.pathname}?join=${net.code}`;

function updateMpUI() {
  const hosting = net.role === 'host';
  const visiting = isGuest();
  $('mpIdle').classList.toggle('hidden', hosting || visiting);
  $('mpHosting').classList.toggle('hidden', !hosting);
  $('mpVisiting').classList.toggle('hidden', !visiting);
  if (hosting) {
    $('inviteCode').textContent = net.code;
    $('inviteLink').value = inviteLink();
    $('mpStatus').textContent = mp.on ? `${game.partner.name} is here with you.` : 'Send this link to your friend. Waiting for them to join...';
  }
  if (visiting) $('visitingName').textContent = game.partner.name;
  const badge = $('mpBadge');
  badge.classList.toggle('hidden', !hosting && !visiting);
  badge.textContent = mp.on ? `Together with ${game.partner.name}` : hosting ? 'Waiting for your friend...' : '';
  badge.classList.toggle('live', mp.on);
}

$('inviteBtn').addEventListener('click', async () => {
  const btn = $('inviteBtn');
  btn.disabled = true;
  btn.textContent = 'Creating invite...';
  try {
    await net.host();
  } catch (err) {
    ui.toast(err.message || 'Could not create an invite');
    net.destroy();
  }
  btn.disabled = false;
  btn.textContent = 'Invite a friend';
  updateMpUI();
});

$('copyLink').addEventListener('click', async () => {
  const input = $('inviteLink');
  try {
    await navigator.clipboard.writeText(input.value);
  } catch {
    input.select();
    document.execCommand('copy');
  }
  ui.toast('Invite link copied. Send it to your friend!');
});

$('stopInvite').addEventListener('click', () => {
  if (mp.on) { net.send({ t: 'bye' }); onPeerLost(); }
  net.destroy();
  updateMpUI();
  ui.toast('Invite closed');
});

$('leaveBtn').addEventListener('click', () => {
  net.send({ t: 'bye' });
  mp.on = false;
  net.destroy();
  location.href = location.pathname;
});

function setJoinStatus(text) { $('joinStatus').textContent = text; }

async function joinGame() {
  const code = $('joinCode').value.trim().toUpperCase();
  if (code.length !== 6) { setJoinStatus('Type the 6-letter code from your friend.'); return; }
  const name = $('myName').value.trim();
  if (!name) { setJoinStatus('Type your name first.'); $('myName').focus(); return; }
  $('joinBtn').disabled = true;
  setJoinStatus('Connecting...');
  try {
    await net.join(code);
    setJoinStatus('Connected! Popping into their world...');
    net.send({ t: 'hello', name, look: { me: profile.me, outfit: profile.outfit, hair: profile.hair } });
  } catch (err) {
    net.destroy();
    setJoinStatus(err.message || 'Could not connect.');
    $('joinBtn').disabled = false;
  }
}
$('joinBtn').addEventListener('click', joinGame);
$('joinCode').addEventListener('keydown', e => { if (e.code === 'Enter') { e.stopPropagation(); joinGame(); } });
$('menuJoinBtn').addEventListener('click', () => {
  const code = $('menuJoinCode').value.trim().toUpperCase();
  if (code.length !== 6) { ui.toast('Type the 6-letter code from your friend'); return; }
  save();
  location.href = `${location.pathname}?join=${code}`;
});
updateMpUI();

// ---------- Loop ----------
const clock = new THREE.Clock();
let mapT = 0;
const SIM_STEPS = params.has('debug') ? Number(params.get('speed')) || 1 : 1;

function tick() {
  const dt = Math.min(clock.getDelta(), 0.05);
  for (let i = 0; i < SIM_STEPS; i++) step(dt);
  hearts.update(dt);
  ui.updateBubbles(camera);
  if (game.started) updateHUD();
  if ((mapT += dt) > 0.1) { mapT = 0; minimap.draw(chars, game.active, car); }
  renderer.render(scene, camera);
  requestAnimationFrame(tick);
}

function step(dt) {
  const input = game.started && !overlayOpen() ? readInput() : { x: 0, z: 0, run: false, jump: false };

  // Time of day (the host's clock wins; the friend's copy is corrected on every update)
  const before = game.hours;
  if (game.warp !== null) {
    game.hours = (game.hours + dt * 0.5) % 24;
    if (before < game.warp && game.hours >= game.warp) game.warp = null;
  } else {
    game.hours = (game.hours + dt * HOURS_PER_SEC * SPEEDS[game.speedIdx]) % 24;
  }
  if (game.hours < before) game.day++;
  if (!game.started) cam.yaw += dt * 0.06;
  sky.update(game.hours, game.driving || mp.riding ? car.pos : game.player.pos);
  world.update(dt, sky.night);

  // Moving cancels whatever you're sitting in, solo dancing and waving.
  const moving = input.x || input.z;
  const mine = actOf(game.player);
  if (moving && mine?.cur.phase === 'active') mine.end();
  if (moving && isGuest() && mp.owned && mp.remoteAct?.ph === 'active' && !mp.endAsked) { mp.endAsked = true; net.send({ t: 'req', k: 'end' }); }
  if (soloDance && (moving || game.player.pose !== 'dance')) { soloDance = false; if (game.player.mode === 'busy') game.player.mode = 'player'; }
  if (waveT > 0 && (waveT -= dt) <= 0 && game.player.pose === 'wave') game.player.setPose('idle');

  const colliders = world.colliders.concat(car.colliders());
  if (game.driving) car.update(dt, input, world.colliders, sky.night, true);
  else if (car.owner !== null && car.owner !== game.active) car.applyNet(dt);
  else car.update(dt, input, world.colliders, sky.night, false);
  acts.forEach(A => A.update(dt));
  for (const c of chars) {
    if (c.mode === 'hidden') continue;
    c.update(dt, { input, camYaw: cam.yaw, colliders, leader: game.player });
  }

  chars.forEach((c, i) => { c.ring.visible = game.started && i === game.active && c.mode === 'player'; });
  updateCamera(dt);
  netTick(dt);
}

if (params.has('debug')) Object.assign(window, { game, acts, actOf, cam, camera, net, mp, photos });
requestAnimationFrame(tick);
