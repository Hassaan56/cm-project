// Talks to the game server over a WebSocket. The server keeps rooms of two
// (whoever invited + one friend) and passes messages between them.
const ERRORS = {
  'not-found': 'That invite has expired. Ask your friend for a new link.',
  full: 'That world already has two people in it.',
};

export class Net {
  constructor() {
    this.role = null; // 'host' | 'guest' | null
    this.ws = null;
    this.code = null;
    this.peer = false; // is the friend there right now
    this.handlers = {};
    this.waiter = null;
  }

  on(evt, fn) { this.handlers[evt] = fn; return this; }
  emit(evt, ...args) { this.handlers[evt]?.(...args); }
  get connected() { return this.peer && this.ws?.readyState === WebSocket.OPEN; }

  connect() {
    return new Promise((resolve, reject) => {
      const proto = location.protocol === 'https:' ? 'wss' : 'ws';
      const ws = new WebSocket(`${proto}://${location.host}/ws`);
      ws.onopen = () => resolve(ws);
      ws.onerror = () => reject(new Error("Can't reach the game server. Check your internet and try again."));
      this.listen(ws);
    });
  }

  waitFor(types, ms = 15000) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.waiter = null; reject(new Error('The server took too long to answer.')); }, ms);
      this.waiter = { types, resolve: m => { clearTimeout(timer); resolve(m); } };
    });
  }

  async host() {
    this.destroy();
    this.ws = await this.connect();
    this.role = 'host';
    const reply = this.waitFor(['created']);
    this.ws.send(JSON.stringify({ t: 'create' }));
    this.code = (await reply).code;
    return this.code;
  }

  async join(code) {
    this.destroy();
    this.ws = await this.connect();
    this.role = 'guest';
    const reply = this.waitFor(['joined', 'error']);
    this.ws.send(JSON.stringify({ t: 'join', code: code.trim().toUpperCase() }));
    const m = await reply;
    if (m.t === 'error') {
      this.destroy();
      throw new Error(ERRORS[m.reason] || 'Could not join.');
    }
    this.code = code;
    this.peer = true;
  }

  listen(ws) {
    ws.onmessage = e => {
      if (ws !== this.ws && this.ws) return;
      let m;
      try { m = JSON.parse(e.data); } catch { return; }
      if (this.waiter?.types.includes(m.t)) {
        const w = this.waiter;
        this.waiter = null;
        w.resolve(m);
        return;
      }
      switch (m.t) {
        case 'peer-joined': this.peer = true; this.emit('open'); return;
        case 'peer-left':
        case 'host-left': this.peerGone(); return;
        default: this.emit('message', m);
      }
    };
    ws.onclose = () => {
      if (ws !== this.ws) return;
      this.ws = null;
      this.peerGone();
      this.role = null;
      this.code = null;
      this.emit('ended');
    };
  }

  peerGone() {
    if (!this.peer) return;
    this.peer = false;
    this.emit('close');
  }

  // Host only: forget the current friend (the room stays open for a rejoin).
  kick() { this.peer = false; }

  destroy() {
    const ws = this.ws;
    this.ws = null;
    this.peer = false;
    this.role = null;
    this.code = null;
    this.waiter = null;
    ws?.close();
  }

  send(msg) {
    if (this.connected) this.ws.send(JSON.stringify(msg));
  }
}
