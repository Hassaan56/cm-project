import * as THREE from 'three';
import { mat, box, cyl, rng, canvasTexture } from './utils.js';

const V = (x, z, y = 0) => new THREE.Vector3(x, y, z);

export function buildWorld(scene) {
  const colliders = [];
  const occluders = [];
  const nightMats = [];
  const frames = [];
  const R = rng(7);
  const add = (...o) => { scene.add(...o); return o[0]; };
  const glow = (color, max = 1.5) => {
    const m = mat(color, { emissive: color, emissiveIntensity: 0 });
    nightMats.push({ m, max });
    return m;
  };

  // ---------- Ground ----------
  const grassTex = canvasTexture(256, 256, (g, w, h) => {
    g.fillStyle = '#6aa84f'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 2500; i++) {
      const l = 35 + R() * 25;
      g.fillStyle = `hsl(${95 + R() * 25}, 45%, ${l}%)`;
      g.fillRect(R() * w, R() * h, 2, 2 + R() * 4);
    }
  });
  grassTex.wrapS = grassTex.wrapT = THREE.RepeatWrapping;
  grassTex.repeat.set(120, 120);
  const ground = add(new THREE.Mesh(new THREE.PlaneGeometry(800, 800), mat('#ffffff', { map: grassTex })));
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;

  const flat = (geo, material, x, z, y = 0.02) => {
    const m = add(new THREE.Mesh(geo, material));
    m.rotation.x = -Math.PI / 2; m.position.set(x, y, z); m.receiveShadow = true;
    return m;
  };

  // Ring road with dashed center line.
  flat(new THREE.RingGeometry(41, 49, 160), mat('#4a4a52', { roughness: 0.95 }), 0, 0, 0.02);
  flat(new THREE.RingGeometry(48.7, 49.2, 160), mat('#e8e2d0'), 0, 0, 0.025);
  flat(new THREE.RingGeometry(40.8, 41.3, 160), mat('#e8e2d0'), 0, 0, 0.025);
  const dashMat = mat('#f5d36b');
  for (let i = 0; i < 80; i++) {
    const a = (i / 80) * Math.PI * 2;
    const d = flat(new THREE.PlaneGeometry(0.25, 1.6), dashMat, Math.cos(a) * 45, Math.sin(a) * 45, 0.03);
    d.rotation.z = -a;
  }
  const stone = mat('#d8c8a8');
  flat(new THREE.PlaneGeometry(2.2, 45), stone, 0, 18.5, 0.025);
  flat(new THREE.PlaneGeometry(4.2, 6.5), mat('#8a8a90'), 11.5, -1.5, 0.025);
  flat(new THREE.PlaneGeometry(2.0, 26), stone, 11, 12, 0.026).rotation.z = 0.9;

  // ---------- House ----------
  const H = 3.2, T = 0.3;
  const wallDefs = [
    { w: 16.3, d: T, x: 0, z: -16, c: [-8.15, 8.15, -16.15, -15.85] },
    { w: T, d: 12, x: -8, z: -10, c: [-8.15, -7.85, -16, -4] },
    { w: T, d: 12, x: 8, z: -10, c: [7.85, 8.15, -16, -4] },
    { w: 7.15, d: T, x: -4.575, z: -4, c: [-8.15, -1, -4.15, -3.85] },
    { w: 7.15, d: T, x: 4.575, z: -4, c: [1, 8.15, -4.15, -3.85] },
  ];
  const windowDefs = [
    [0, 1.8, -16.17, Math.PI, 0], [-8.17, 1.8, -10, -Math.PI / 2, 1], [8.17, 1.7, -7, Math.PI / 2, 2],
    [-4.5, 1.8, -3.83, 0, 3], [4.5, 1.8, -3.83, 0, 4],
  ];
  const walls = wallDefs.map(d => {
    const w = add(box(d.w, H, d.d, mat('#f3e6d0', { transparent: true }), d.x, H / 2, d.z));
    colliders.push({ minX: d.c[0], maxX: d.c[1], minZ: d.c[2], maxZ: d.c[3] });
    occluders.push(w);
    return w;
  });
  const lintel = add(box(2.3, H - 2.4, T, mat('#f3e6d0', { transparent: true }), 0, 2.4 + (H - 2.4) / 2, -4));
  occluders.push(lintel);
  for (const [x, y, z, ry, wi] of windowDefs) {
    const g = new THREE.Group();
    const frameM = mat('#7a5236', { transparent: true });
    g.add(box(1.9, 1.3, 0.06, frameM));
    const glass = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 1.1), new THREE.MeshStandardMaterial({ color: '#9fc8e8', roughness: 0.15, metalness: 0.3, emissive: '#ffcf86', emissiveIntensity: 0, transparent: true }));
    glass.position.z = 0.035;
    nightMats.push({ m: glass.material, max: 1.1 });
    g.add(glass, box(0.06, 1.1, 0.07, frameM, 0, 0, 0.03), box(1.7, 0.06, 0.07, frameM, 0, 0, 0.03));
    const sill = box(2.0, 0.08, 0.2, frameM, 0, -0.68, 0.08); g.add(sill);
    // Window lives in wall-local space so it fades with the wall.
    const wall = walls[wi];
    g.position.set(x - wall.position.x, y - wall.position.y, z - wall.position.z);
    g.rotation.y = ry;
    wall.add(g);
  }
  // Door frame, mat, porch light
  const wood = mat('#7a5236');
  add(box(0.15, 2.45, 0.4, wood, -1.08, 1.22, -4), box(0.15, 2.45, 0.4, wood, 1.08, 1.22, -4), box(2.3, 0.15, 0.4, wood, 0, 2.45, -4));
  const doorPanel = add(box(0.08, 2.3, 1.9, mat('#a0522d'), 1.0, 1.15, -3.0));
  doorPanel.position.set(1.05, 1.15, -3.05);
  flat(new THREE.PlaneGeometry(1.6, 0.9), mat('#b5523b'), 0, -3.3, 0.03);
  add(box(0.18, 0.25, 0.18, glow('#ffd9a0', 2.5), -1.45, 2.3, -3.8));

  // Floor & roof
  const floorTex = canvasTexture(256, 256, (g, w, h) => {
    for (let i = 0; i < 8; i++) {
      g.fillStyle = `hsl(28, 40%, ${38 + (i % 3) * 5}%)`;
      g.fillRect(0, (i * h) / 8, w, h / 8 - 2);
      g.fillStyle = 'rgba(0,0,0,0.25)';
      g.fillRect(((i * 97) % w), (i * h) / 8, 2, h / 8);
    }
  });
  floorTex.wrapS = floorTex.wrapT = THREE.RepeatWrapping;
  floorTex.repeat.set(4, 4);
  flat(new THREE.PlaneGeometry(16, 12), mat('#ffffff', { map: floorTex, roughness: 0.6 }), 0, -10, 0.015);

  const roof = add(new THREE.Group());
  const roofMesh = new THREE.Mesh(new THREE.ConeGeometry(1, 1, 4).rotateY(Math.PI / 4), mat('#c0504d', { flatShading: true }));
  roofMesh.scale.set(18 / Math.SQRT2, 3, 14 / Math.SQRT2);
  roofMesh.position.set(0, H + 1.5, -10);
  roofMesh.castShadow = true;
  roof.add(roofMesh);
  roof.add(box(0.8, 2.2, 0.8, mat('#8a4a3a'), 4.5, H + 2.2, -12));
  const ceiling = box(16, 0.1, 12, mat('#fff8ee'), 0, H - 0.05, -10);
  roof.add(ceiling);

  // ---------- Interior ----------
  flat(new THREE.CircleGeometry(2.4, 40), mat('#c9a0dc'), 0, -10, 0.03);
  flat(new THREE.CircleGeometry(2.0, 40), mat('#e8c6f0'), 0, -10, 0.035);
  // Everything added from here to the end of the interior also blocks the indoor camera.
  const interiorFrom = scene.children.length;

  // Bed
  const bedWood = mat('#8b5a3c');
  add(box(1.9, 0.4, 2.2, bedWood, -5.5, 0.2, -14.7));
  add(box(1.8, 0.2, 2.1, mat('#fbf8f2'), -5.5, 0.5, -14.7));
  add(box(1.95, 1.2, 0.12, bedWood, -5.5, 0.6, -15.78));
  add(box(0.7, 0.12, 0.4, mat('#ffffff'), -5.95, 0.66, -15.4), box(0.7, 0.12, 0.4, mat('#ffffff'), -5.05, 0.66, -15.4));
  const blanket = add(box(1.95, 0.1, 1.5, mat('#ff9fb2'), -5.5, 0.65, -14.45));
  colliders.push({ minX: -6.45, maxX: -4.55, minZ: -15.85, maxZ: -13.6 });
  add(box(0.6, 0.6, 0.5, bedWood, -3.9, 0.3, -15.5));
  add(cyl(0.05, 0.08, 0.4, mat('#555'), 8)).position.set(-3.9, 0.8, -15.5);
  const lampShade = add(cyl(0.12, 0.2, 0.25, glow('#ffe6b0', 1.2), 12));
  lampShade.position.set(-3.9, 1.1, -15.5);

  // Wardrobe + mirror
  const wardrobe = add(box(0.6, 2.2, 1.6, mat('#9c6b48'), -7.5, 1.1, -8));
  wardrobe.add(box(0.02, 2.0, 0.02, mat('#5a3a22'), 0.31, 0, 0));
  wardrobe.add(box(0.05, 0.25, 0.05, mat('#d4af37', { metalness: 0.8, roughness: 0.3 }), 0.32, 0, -0.12));
  wardrobe.add(box(0.05, 0.25, 0.05, mat('#d4af37', { metalness: 0.8, roughness: 0.3 }), 0.32, 0, 0.12));
  colliders.push({ minX: -7.85, maxX: -7.18, minZ: -8.8, maxZ: -7.2 });
  const mirror = add(new THREE.Mesh(new THREE.PlaneGeometry(0.8, 1.6), mat('#cfe3f0', { metalness: 0.9, roughness: 0.05 })));
  mirror.position.set(-7.83, 1.3, -10.2); mirror.rotation.y = Math.PI / 2;
  add(box(0.05, 1.7, 0.9, wood, -7.86, 1.3, -10.2));

  // Sofa
  const sofaM = mat('#5b7fa6');
  add(box(2.4, 0.45, 0.9, sofaM, 4.5, 0.225, -15.2), box(2.4, 0.65, 0.25, sofaM, 4.5, 0.75, -15.62));
  add(box(0.25, 0.65, 0.9, sofaM, 3.3, 0.33, -15.2), box(0.25, 0.65, 0.9, sofaM, 5.7, 0.33, -15.2));
  add(box(0.4, 0.35, 0.12, mat('#ffcf6b'), 3.6, 0.65, -15.4), box(0.4, 0.35, 0.12, mat('#ff8fab'), 5.4, 0.65, -15.4));
  colliders.push({ minX: 3.15, maxX: 5.85, minZ: -15.85, maxZ: -15.45 });

  // TV
  add(box(1.6, 0.5, 0.4, mat('#3a2a20'), 4.5, 0.25, -11));
  add(box(1.5, 0.85, 0.06, mat('#111'), 4.5, 1.0, -11));
  const tvCanvas = document.createElement('canvas');
  tvCanvas.width = 256; tvCanvas.height = 144;
  const tvTex = new THREE.CanvasTexture(tvCanvas);
  tvTex.colorSpace = THREE.SRGBColorSpace;
  const tvMat = new THREE.MeshBasicMaterial({ color: '#111', map: null });
  const screen = add(new THREE.Mesh(new THREE.PlaneGeometry(1.38, 0.76), tvMat));
  screen.position.set(4.5, 1.0, -11.04); screen.rotation.y = Math.PI;
  colliders.push({ minX: 3.7, maxX: 5.3, minZ: -11.2, maxZ: -10.8 });
  const tv = {
    on: false, t: 0,
    setOn(v) { this.on = v; tvMat.map = v ? tvTex : null; tvMat.color.set(v ? '#ffffff' : '#111111'); tvMat.needsUpdate = true; },
    update(dt) {
      if (!this.on) return;
      this.t += dt;
      const g = tvCanvas.getContext('2d'), w = 256, h = 144, t = this.t;
      const grad = g.createLinearGradient(0, 0, 0, h);
      grad.addColorStop(0, `hsl(${(t * 12) % 360}, 60%, 55%)`);
      grad.addColorStop(1, `hsl(${(t * 12 + 60) % 360}, 70%, 30%)`);
      g.fillStyle = grad; g.fillRect(0, 0, w, h);
      g.fillStyle = '#ffe08a';
      g.beginPath(); g.arc(128 + Math.sin(t * 0.7) * 70, 70 + Math.cos(t * 0.5) * 20, 22, 0, Math.PI * 2); g.fill();
      g.fillStyle = 'rgba(0,0,0,0.35)';
      for (let i = 0; i < 6; i++) { const x = ((t * 40 + i * 60) % 320) - 40; g.fillRect(x, 100 + Math.sin(t * 3 + i) * 5, 30, 44); }
      g.fillStyle = '#fff'; g.font = 'bold 14px sans-serif'; g.fillText('LOVE TV', 8, 18);
      tvTex.needsUpdate = true;
    },
  };

  // Dining table + chairs
  const tableM = mat('#a87048');
  add(box(1.6, 0.06, 0.9, tableM, 5, 0.76, -7));
  for (const [lx, lz] of [[4.3, -7.35], [5.7, -7.35], [4.3, -6.65], [5.7, -6.65]]) add(box(0.06, 0.74, 0.06, tableM, lx, 0.37, lz));
  colliders.push({ minX: 4.2, maxX: 5.8, minZ: -7.45, maxZ: -6.55 });
  const chair = (x, z, backDx, m = tableM) => {
    add(box(0.5, 0.06, 0.5, m, x, 0.44, z));
    add(box(0.06, 0.6, 0.5, m, x + backDx, 0.74, z));
    for (const [a, b] of [[-0.2, -0.2], [0.2, -0.2], [-0.2, 0.2], [0.2, 0.2]]) add(box(0.04, 0.44, 0.04, m, x + a, 0.22, z + b));
  };
  chair(3.85, -7, -0.25); chair(6.15, -7, 0.25);
  const homeFood = makeFood(5, -7, 0.8, 'x');
  scene.add(homeFood.group);
  add(cyl(0.06, 0.08, 0.2, mat('#88c8d8', { transparent: true, opacity: 0.7 }), 10)).position.set(5, 0.89, -7);
  for (let i = 0; i < 3; i++) {
    const f = add(new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), mat(['#ff5d7a', '#ffd166', '#ffffff'][i])));
    f.position.set(5 + (i - 1) * 0.05, 1.03 + (i % 2) * 0.04, -7);
  }

  // Plants
  for (const [px, pz] of [[-7.3, -4.7], [7.3, -4.7], [-1.8, -15.5], [7.3, -15.4]]) plant(px, pz);
  function plant(x, z) {
    add(cyl(0.22, 0.17, 0.4, mat('#c4683f'), 10)).position.set(x, 0.2, z);
    const b = add(new THREE.Mesh(new THREE.IcosahedronGeometry(0.38, 1), mat('#3f8f4a', { flatShading: true })));
    b.position.set(x, 0.75, z); b.castShadow = true;
  }

  // Indoor light
  const houseLight = add(new THREE.PointLight('#ffd9a0', 6, 24, 1.2));
  houseLight.position.set(0, 2.8, -10);
  const ceilLamp = box(0.6, 0.08, 0.6, glow('#fff1cc', 2));
  ceilLamp.position.set(0, H - 0.14, -10);
  roof.add(ceilLamp);

  // Photo frames
  const frameDefs = [
    { id: 'frame-1', x: -2.3, y: 1.75, z: -15.83, ry: 0, w: 1.1, h: 0.8 },
    { id: 'frame-2', x: 0, y: 1.85, z: -15.83, ry: 0, w: 0.9, h: 1.2 },
    { id: 'frame-3', x: 2.3, y: 1.75, z: -15.83, ry: 0, w: 1.1, h: 0.8 },
    { id: 'frame-4', x: 7.83, y: 1.8, z: -12.8, ry: -Math.PI / 2, w: 1.0, h: 0.75 },
    { id: 'frame-5', x: 7.83, y: 1.8, z: -9.6, ry: -Math.PI / 2, w: 0.75, h: 1.0 },
  ];
  for (const d of frameDefs) {
    const g = add(new THREE.Group());
    g.position.set(d.x, d.y, d.z); g.rotation.y = d.ry;
    g.add(box(d.w + 0.14, d.h + 0.14, 0.05, mat('#c9a04a', { metalness: 0.6, roughness: 0.35 })));
    g.add(box(d.w + 0.02, d.h + 0.02, 0.055, mat('#f7f1e6')));
    const pic = new THREE.Mesh(new THREE.PlaneGeometry(d.w - 0.06, d.h - 0.06), new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.6, emissive: '#ffffff', emissiveIntensity: 0.25 }));
    pic.position.z = 0.03;
    g.add(pic);
    frames.push({ id: d.id, mesh: pic, w: d.w - 0.06, h: d.h - 0.06 });
  }

  const interior = scene.children.slice(interiorFrom);

  // ---------- Garden ----------
  for (const sx of [-1, 1]) {
    add(box(5.5, 0.2, 0.8, mat('#5a3a28'), sx * 4.6, 0.1, -3.2));
    for (let i = 0; i < 12; i++) {
      const f = add(new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), mat(['#ff6b8a', '#ffd166', '#c792ea', '#ffffff'][i % 4])));
      f.position.set(sx * 4.6 + (i - 5.5) * 0.42, 0.32, -3.2 + (i % 2 ? 0.15 : -0.15));
    }
  }
  // Mailbox
  add(box(0.1, 1.1, 0.1, wood, 1.7, 0.55, -1)); add(box(0.35, 0.3, 0.5, mat('#c0504d'), 1.7, 1.2, -1));

  // ---------- Café ----------
  const cafe = { x: 22, z: 18 };
  const kiosk = add(box(6, 3, 4, mat('#fbe3c8', { transparent: true }), 22, 1.5, 24));
  colliders.push({ minX: 19, maxX: 25, minZ: 22, maxZ: 26 });
  occluders.push(kiosk);
  add(box(6.6, 0.25, 4.6, mat('#7a4a32'), 22, 3.1, 24));
  const stripes = canvasTexture(256, 64, (g, w, h) => { for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? '#ffffff' : '#e85a6b'; g.fillRect((i * w) / 8, 0, w / 8, h); } });
  const awning = add(box(6.2, 0.05, 1.5, mat('#ffffff', { map: stripes })));
  awning.position.set(22, 2.55, 21.35); awning.rotation.x = -0.35;
  const opening = add(new THREE.Mesh(new THREE.PlaneGeometry(4, 1.1), mat('#3a2a22')));
  opening.position.set(22, 1.7, 21.98); opening.rotation.y = Math.PI;
  add(box(4.4, 0.1, 0.5, mat('#7a4a32'), 22, 1.12, 21.8));
  const signTex = canvasTexture(512, 128, (g, w, h) => {
    g.fillStyle = '#3a1a28'; g.fillRect(0, 0, w, h);
    g.fillStyle = '#ffd6e0'; g.font = 'bold 64px Georgia, serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText('Café Amour', w / 2, h / 2 + 4);
  });
  const signMat = new THREE.MeshStandardMaterial({ map: signTex, emissive: '#ffffff', emissiveMap: signTex, emissiveIntensity: 0.3 });
  nightMats.push({ m: signMat, max: 1.2, min: 0.3 });
  const sign = add(new THREE.Mesh(new THREE.PlaneGeometry(3.6, 0.9), signMat));
  sign.position.set(22, 3.75, 21.96); sign.rotation.y = Math.PI;
  add(box(3.8, 1.0, 0.08, mat('#3a1a28'), 22, 3.75, 22.02));

  const deck = add(box(9, 0.04, 6.4, mat('#b98b5e'), 22, 0.02, 18.6));
  deck.receiveShadow = true;
  const cloth = mat('#ffffff');
  const roundTable = (x, z, r = 0.55) => {
    add(cyl(r, r, 0.05, cloth, 24)).position.set(x, 0.76, z);
    add(cyl(r + 0.02, r + 0.05, 0.12, cloth, 24)).position.set(x, 0.68, z);
    add(cyl(0.05, 0.05, 0.7, mat('#333'), 8)).position.set(x, 0.38, z);
    colliders.push({ x, z, r: r + 0.05 });
  };
  roundTable(22, 18);
  const cafeChairM = mat('#2f2f35', { metalness: 0.5, roughness: 0.4 });
  chair(20.95, 18, -0.25, cafeChairM); chair(23.05, 18, 0.25, cafeChairM);
  for (const [x, z] of [[18.6, 16.2], [25.4, 16.2]]) {
    roundTable(x, z, 0.4);
    chair(x - 0.8, z, -0.25, cafeChairM); chair(x + 0.8, z, 0.25, cafeChairM);
  }
  const cafeFood = makeFood(22, 18, 0.8, 'x', true);
  scene.add(cafeFood.group);
  add(cyl(0.03, 0.03, 0.12, mat('#fff8e0'), 8)).position.set(22, 0.85, 18);
  const flameMat = new THREE.MeshBasicMaterial({ color: '#ffb347' });
  const flame = add(new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 6), flameMat));
  flame.position.set(22, 0.93, 18); flame.scale.y = 1.8;
  const rose = add(new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), mat('#d61f4a')));
  rose.position.set(22, 0.92, 18.25);

  // String lights over the deck
  const bulbMat = glow('#ffd27a', 3);
  const posts = [[17.6, 15.3], [26.4, 15.3], [26.4, 21.6], [17.6, 21.6]];
  for (const [x, z] of posts) add(cyl(0.06, 0.08, 3.2, mat('#3a2a20'), 8)).position.set(x, 1.6, z);
  for (let p = 0; p < 4; p++) {
    const [ax, az] = posts[p], [bx, bz] = posts[(p + 1) % 4];
    for (let i = 1; i < 12; i++) {
      const t = i / 12;
      const b = add(new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 6), bulbMat));
      b.position.set(ax + (bx - ax) * t, 3.1 - Math.sin(t * Math.PI) * 0.5, az + (bz - az) * t);
    }
  }
  const cafeLight = add(new THREE.PointLight('#ffb36b', 0, 16, 1.3));
  cafeLight.position.set(22, 2.5, 18);

  // ---------- Lake & bench ----------
  const water = flat(new THREE.CircleGeometry(13, 64), new THREE.MeshStandardMaterial({ color: '#3a8fc4', roughness: 0.08, metalness: 0.2, transparent: true, opacity: 0.92 }), -70, 0, 0.04);
  flat(new THREE.RingGeometry(12.6, 15.5, 64), mat('#e3cf9a'), -70, 0, 0.03);
  colliders.push({ x: -70, z: 0, r: 12.8 });
  for (let i = 0; i < 9; i++) {
    const a = R() * Math.PI * 2, r = 4 + R() * 7;
    const pad = flat(new THREE.CircleGeometry(0.45, 12, 0.3, Math.PI * 1.8), mat('#4f9a4a'), -70 + Math.cos(a) * r, Math.sin(a) * r, 0.06);
    pad.rotation.z = R() * 6;
  }
  for (let i = 0; i < 22; i++) {
    const a = R() * Math.PI * 2;
    if (Math.cos(a) > 0.6) continue;
    const r = 13.3 + R() * 1.5;
    const rock = add(new THREE.Mesh(new THREE.DodecahedronGeometry(0.3 + R() * 0.5, 0), mat('#8a8a8a', { flatShading: true })));
    rock.position.set(-70 + Math.cos(a) * r, 0.1, Math.sin(a) * r); rock.castShadow = true;
  }

  const benchWood = mat('#9a6a3a'), iron = mat('#2a2a2e', { metalness: 0.6, roughness: 0.4 });
  const bench = add(new THREE.Group());
  bench.position.set(-54, 0, 0);
  bench.add(box(0.5, 0.06, 2.1, benchWood, 0, 0.45, 0));
  const back = box(0.05, 0.45, 2.1, benchWood, 0.27, 0.78, 0); back.rotation.z = -0.15; bench.add(back);
  for (const z of [-0.9, 0.9]) { bench.add(box(0.5, 0.45, 0.06, iron, 0, 0.22, z)); bench.add(box(0.05, 0.5, 0.06, iron, 0.26, 0.7, z)); }
  add(cyl(0.07, 0.09, 3.6, iron, 8)).position.set(-53.6, 1.8, -2.2);
  add(new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8), glow('#ffe6a8', 3))).position.set(-53.6, 3.7, -2.2);
  for (let i = 0; i < 30; i++) {
    const f = add(new THREE.Mesh(new THREE.SphereGeometry(0.09, 6, 5), mat(['#ff6b8a', '#ffd166', '#c792ea', '#ffffff'][i % 4])));
    const a = R() * Math.PI * 2, r = 1.8 + R() * 2;
    f.position.set(-53 + Math.cos(a) * r * 0.6, 0.1, Math.sin(a) * r);
  }

  // ---------- Trees ----------
  const trunkG = new THREE.CylinderGeometry(0.15, 0.25, 1.8, 7);
  const blobG = new THREE.IcosahedronGeometry(1.3, 0);
  const pineG = new THREE.ConeGeometry(1.3, 3.2, 7);
  const trunkM = mat('#6b4a2e');
  const leafMs = ['#4f8f3a', '#3f7f3a', '#6aa84f', '#5c9e45'].map(c => mat(c, { flatShading: true }));
  const blossomM = mat('#ffb7c9', { flatShading: true });
  const avoid = (x, z) => {
    const r = Math.hypot(x, z);
    if (r > 38 && r < 52) return true;
    if (x > -11 && x < 14 && z > -19 && z < 4) return true;
    if (Math.abs(x) < 3 && z > -4 && z < 42) return true;
    if (x > 15 && x < 29 && z > 12 && z < 28) return true;
    if (Math.hypot(x + 70, z) < 17) return true;
    if (x > -62 && x < -48 && Math.abs(z) < 8) return true;
    if (Math.abs(z - 12) < 3 && x > 2 && x < 20) return true;
    return r > 88;
  };
  let placed = 0;
  while (placed < 110) {
    const a = R() * Math.PI * 2, r = 8 + R() * 82;
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (avoid(x, z)) continue;
    placed++;
    const s = 0.8 + R() * 0.8;
    const g = add(new THREE.Group());
    g.position.set(x, 0, z); g.scale.setScalar(s); g.rotation.y = R() * 6;
    const tr = new THREE.Mesh(trunkG, trunkM); tr.position.y = 0.9; tr.castShadow = true; g.add(tr);
    const kind = R();
    if (kind < 0.35) {
      for (let k = 0; k < 2; k++) { const p = new THREE.Mesh(pineG, leafMs[1]); p.position.y = 2.4 + k * 1.2; p.scale.setScalar(1 - k * 0.3); p.castShadow = true; g.add(p); }
    } else {
      const lm = kind > 0.9 ? blossomM : leafMs[(R() * 4) | 0];
      for (let k = 0; k < 3; k++) {
        const b = new THREE.Mesh(blobG, lm);
        b.position.set((R() - 0.5) * 1.2, 2.4 + R() * 0.8, (R() - 0.5) * 1.2);
        b.scale.setScalar(0.7 + R() * 0.4); b.castShadow = true; g.add(b);
      }
    }
    colliders.push({ x, z, r: 0.3 * s });
  }

  // Wildflowers (instanced)
  const flowerG = new THREE.SphereGeometry(0.08, 6, 4);
  const flowers = new THREE.InstancedMesh(flowerG, mat('#ffffff'), 600);
  const m4 = new THREE.Matrix4(), col = new THREE.Color();
  const fcols = ['#ff6b8a', '#ffd166', '#c792ea', '#ffffff', '#7ec8ff'];
  let fi = 0;
  while (fi < 600) {
    const a = R() * Math.PI * 2, r = 6 + R() * 84;
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (avoid(x, z) && !(Math.hypot(x + 70, z) < 17 && Math.hypot(x + 70, z) > 15.6)) continue;
    m4.makeTranslation(x, 0.08, z);
    flowers.setMatrixAt(fi, m4);
    flowers.setColorAt(fi, col.set(fcols[fi % 5]));
    fi++;
  }
  add(flowers);

  // Lampposts around the ring road
  const lampM = glow('#ffe6a8', 3);
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * Math.PI * 2 + 0.1;
    const x = Math.cos(a) * 39.6, z = Math.sin(a) * 39.6;
    add(cyl(0.07, 0.1, 4, iron, 8)).position.set(x, 2, z);
    const bulb = add(new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 8), lampM));
    bulb.position.set(x * 1.02, 4.05, z * 1.02);
    colliders.push({ x, z, r: 0.15 });
  }

  // Distant hills
  for (let i = 0; i < 26; i++) {
    const a = (i / 26) * Math.PI * 2 + R() * 0.2, r = 150 + R() * 70;
    // Keep the west low so the sun can set over the lake.
    const west = Math.cos(a) < -0.6;
    const hgt = west ? 4 + R() * 6 : 18 + R() * 30;
    const hill = add(new THREE.Mesh(new THREE.ConeGeometry(30 + R() * 30, hgt, 7), mat(R() > 0.5 ? '#4e7a52' : '#5f8a5c', { flatShading: true })));
    hill.position.set(Math.cos(a) * r, hgt / 2 - 2, Math.sin(a) * r);
  }

  // Clouds
  const clouds = [];
  const cloudM = mat('#ffffff', { roughness: 1, flatShading: true, emissive: '#ffffff', emissiveIntensity: 0.15 });
  for (let i = 0; i < 14; i++) {
    const g = add(new THREE.Group());
    for (let k = 0; k < 4; k++) {
      const c = new THREE.Mesh(new THREE.IcosahedronGeometry(4 + R() * 4, 0), cloudM);
      c.position.set(k * 5 - 7, R() * 2, R() * 3); g.add(c);
    }
    const a = R() * Math.PI * 2, r = 60 + R() * 140;
    g.position.set(Math.cos(a) * r, 55 + R() * 30, Math.sin(a) * r);
    clouds.push(g);
  }

  // Fireflies
  const ffCount = 80;
  const ffGeo = new THREE.BufferGeometry();
  const ffBase = [];
  for (let i = 0; i < ffCount; i++) {
    const nearLake = i < 50;
    const x = nearLake ? -58 + (R() - 0.5) * 16 : (R() - 0.5) * 30;
    const z = nearLake ? (R() - 0.5) * 24 : 2 + R() * 10;
    ffBase.push(x, 0.5 + R() * 2, z);
  }
  ffGeo.setAttribute('position', new THREE.Float32BufferAttribute(ffBase.slice(), 3));
  const fireflies = add(new THREE.Points(ffGeo, new THREE.PointsMaterial({ color: '#ffef8a', size: 0.18, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false })));

  // ---------- Activity spots ----------
  const spots = {
    bench: {
      center: V(-54, 0), radius: 2.4,
      slots: [
        { pos: V(-54, -0.45), yaw: -Math.PI / 2, approach: V(-54.9, -0.6), lean: -0.08 },
        { pos: V(-54, 0.45), yaw: -Math.PI / 2, approach: V(-54.9, 0.6), lean: 0.3 },
      ],
    },
    bed: {
      center: V(-5.5, -14.2), radius: 2.4, bedH: 0.6,
      slots: [
        { pos: V(-5.95, -13.85), yaw: 0, approach: V(-6.95, -14.2), lean: -0.1 },
        { pos: V(-5.05, -13.85), yaw: 0, approach: V(-4.05, -14.2), lean: 0.35 },
      ],
    },
    sofa: {
      center: V(4.5, -14.4), radius: 1.9,
      slots: [
        { pos: V(4.0, -15.0), yaw: 0, approach: V(4.0, -13.9), lean: -0.08 },
        { pos: V(5.0, -15.0), yaw: 0, approach: V(5.0, -13.9), lean: 0.3 },
      ],
    },
    homeTable: {
      center: V(5, -7), radius: 2.0,
      slots: [
        { pos: V(3.85, -7), yaw: Math.PI / 2, approach: V(3.85, -7.9) },
        { pos: V(6.15, -7), yaw: -Math.PI / 2, approach: V(6.15, -7.9) },
      ],
    },
    cafeTable: {
      center: V(22, 18), radius: 2.3,
      slots: [
        { pos: V(20.95, 18), yaw: Math.PI / 2, approach: V(20.95, 18.9) },
        { pos: V(23.05, 18), yaw: -Math.PI / 2, approach: V(23.05, 18.9) },
      ],
    },
    wardrobe: { center: V(-6.7, -8), radius: 1.5 },
  };

  let t = 0;
  function update(dt, night) {
    t += dt;
    for (const { m, max, min = 0 } of nightMats) m.emissiveIntensity = min + (max - min) * night;
    houseLight.intensity = 2.5 + night * 6;
    cafeLight.intensity = night * (14 + Math.sin(t * 13) * 1.2 + Math.sin(t * 7.3) * 0.8);
    flame.scale.set(1 + Math.sin(t * 20) * 0.15, 1.8 + Math.sin(t * 17) * 0.3, 1);
    water.material.color.setHSL(0.56, 0.55, 0.42 - night * 0.25 + Math.sin(t * 0.8) * 0.01);
    for (const c of clouds) { c.position.x += dt * 0.8; if (c.position.x > 220) c.position.x = -220; }
    fireflies.material.opacity = night * (0.7 + Math.sin(t * 3) * 0.3);
    if (night > 0.05) {
      const p = fireflies.geometry.attributes.position;
      for (let i = 0; i < ffCount; i++) {
        p.array[i * 3] = ffBase[i * 3] + Math.sin(t * 0.5 + i) * 0.8;
        p.array[i * 3 + 1] = ffBase[i * 3 + 1] + Math.sin(t * 0.9 + i * 2) * 0.4;
        p.array[i * 3 + 2] = ffBase[i * 3 + 2] + Math.cos(t * 0.4 + i) * 0.8;
      }
      p.needsUpdate = true;
    }
    tv.update(dt);
  }

  return { colliders, occluders, roof, frames, spots, tv, blanket, homeFood, cafeFood, cafe, interior, update };
}

// Plates with food; `axis` is the direction the two diners face each other along.
function makeFood(cx, cz, y, axis, fancy = false) {
  const group = new THREE.Group();
  const items = [];
  const plateM = mat('#ffffff', { roughness: 0.3 });
  for (const s of [-1, 1]) {
    const px = cx + (axis === 'x' ? s * 0.5 : 0), pz = cz + (axis === 'z' ? s * 0.5 : 0);
    const plate = cyl(0.17, 0.14, 0.02, plateM, 20); plate.position.set(px, y, pz); group.add(plate);
    const food = new THREE.Group();
    food.position.set(px, y + 0.03, pz);
    const pasta = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat(fancy ? '#e8b04a' : '#f0c87a'));
    pasta.scale.y = 0.6; food.add(pasta);
    for (let i = 0; i < 3; i++) {
      const b = new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 6), mat(i % 2 ? '#c0392b' : '#5a9e3a'));
      b.position.set(Math.cos(i * 2.1) * 0.05, 0.05, Math.sin(i * 2.1) * 0.05); food.add(b);
    }
    group.add(food);
    items.push(food);
    if (fancy) {
      const glass = new THREE.Group();
      glass.position.set(px, y, pz + 0.25);
      const stem = cyl(0.008, 0.008, 0.12, mat('#ffffff', { transparent: true, opacity: 0.5 }), 6); stem.position.y = 0.06; glass.add(stem);
      const bowl = cyl(0.04, 0.025, 0.08, mat('#ffffff', { transparent: true, opacity: 0.35 }), 10); bowl.position.y = 0.16; glass.add(bowl);
      const wine = cyl(0.033, 0.024, 0.045, mat('#8e1c3b'), 10); wine.position.y = 0.145; glass.add(wine);
      group.add(glass);
    }
  }
  const food = {
    group, level: 0,
    set(v) { food.level = v; items.forEach(f => { f.visible = v > 0.02; f.scale.setScalar(Math.max(0.02, v)); }); },
  };
  food.set(0);
  return food;
}
