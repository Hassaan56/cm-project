import * as THREE from 'three';
import { ui } from './ui.js';

// Lines: [speaker, text], speaker 0 = him, 1 = her.
const TALKS = [
  [[1, 'Hey you.'], [0, 'Hey yourself. Did you sleep well?'], [1, 'Like a baby. You were snoring though.'], [0, 'I was not!'], [1, 'Haha, it was cute.']],
  [[0, 'What should we do today?'], [1, 'Maybe a drive, then dinner at the café?'], [0, "Perfect plan. I'm driving."], [1, 'Only if I pick the music!']],
  [[1, 'Do you remember the day we met?'], [0, 'How could I forget? You laughed at my joke.'], [1, 'It was a terrible joke.'], [0, 'And yet here we are.']],
  [[0, 'You look really nice today.'], [1, 'Aww, stop it.'], [0, 'I mean it.'], [1, "...you're sweet."]],
  [[1, "I'm getting hungry."], [0, 'Pasta at home or the café?'], [1, "Café! It's more romantic."], [0, 'Café Amour it is.']],
  [[0, 'The sunset by the lake is beautiful.'], [1, "Let's watch it together tonight."], [0, "It's a date."]],
  [[1, 'We should put more photos on the wall.'], [0, 'Yes! Our wall needs more memories.'], [1, 'I have so many good ones.']],
  [[0, 'Race you to the lake?'], [1, "You'd lose."], [0, '...probably, yeah.']],
];
const LINES = {
  date: [[0, 'To us.'], [1, 'To us. Cheers!'], [1, 'This pasta is amazing.'], [0, 'Not as amazing as you.'], [1, 'Cheesy... but I love it.']],
  sunset: [[1, 'Look at those colors...'], [0, 'Beautiful. Just like you.'], [1, 'I wish this moment lasted forever.'], [0, "We'll have a thousand more."]],
  stars: [[0, 'Look, a shooting star!'], [1, 'Did you make a wish?'], [0, "I don't need to. It already came true."]],
  dinner: [[1, 'Smells so good!'], [0, "Chef's special, just for you."], [1, "Mmm, you've outdone yourself."]],
  tv: [[0, 'What are we watching?'], [1, 'Something cozy. Come here.']],
  sleep: [[1, 'Goodnight...'], [0, 'Goodnight. Sweet dreams.']],
  hug: [[1, 'I love you.'], [0, 'I love you more.']],
  kiss: [[1, 'Mmm...'], [0, 'I could do that all day.']],
  shoulder: [[1, 'You make a good pillow.'], [0, 'Stay as long as you like.']],
  hands: [[0, 'Your hands are freezing!'], [1, 'Then hold them tighter.']],
  lap: [[1, 'Comfy?'], [0, 'Never moving again.']],
  headLap: [[1, "Don't stop doing that..."], [0, 'Your hair is so soft.']],
  snuggle: [[1, 'Come closer, it is cold.'], [0, 'Better?'], [1, 'Much better.']],
  blanket: [[1, 'Hey... come here.'], [0, '...'], [1, 'Mmm. Nobody is watching.'], [0, 'Just us two.'], [1, 'I love you so much.']],
  standLean: [[1, 'I just want to stand here a minute.'], [0, 'Then we stand here.']],
};
// Said to yourself when nobody else is online.
const SOLO = {
  sunset: ['What a sunset...', 'This would be perfect with someone next to me.'],
  stars: ['So many stars tonight.'],
  dinner: ['Mmm, not bad at all.'],
  date: ['Table for one... for now.'],
  tv: ["Let's see what's on."],
  sleep: ['Goodnight, world.'],
};

export class Activities {
  constructor(game) {
    this.g = game;
    this.cur = null;
    this.lead = game.chars[0];
    this.other = game.chars[1];
    // Visible effects go through here so multiplayer can mirror them to the other screen.
    this.fx = {
      say: (c, text, dur) => ui.say(c, text, dur),
      toast: text => ui.toast(text),
      fade: on => ui.fade(on),
      hearts: (p, n) => game.hearts.burst(p, n),
    };
  }

  get busy() { return !!this.cur; }

  speakerChar(s) { return this.g.chars.find(c => (s === 1) === c.female); }

  // Seated activity at a spot: the lead snaps into place, the partner (if any) walks over and sits.
  together(spot, def) {
    const player = this.lead, companion = this.other;
    const slotOf = c => spot.slots[c.female ? 1 : 0];
    const solo = !companion;
    const lines = solo ? (def.solo || []).map(t => [player.female ? 1 : 0, t]) : def.lines || [];
    const a = { ...def, spot, elapsed: 0, ready: 0, need: solo ? 1 : 2, phase: 'gather', lineAt: 0, lines: [...lines] };
    if (solo) a.cuddles = null;
    this.cur = a;
    a.participants = solo ? [player] : [player, companion];
    const opts = c => ({ ...(def.opts || {}), lean: solo ? 0 : slotOf(c).lean || 0, bedH: spot.bedH });
    const sit = c => c.snapTo(slotOf(c).pos, slotOf(c).yaw, def.pose, opts(c), 0.7, () => { a.ready++; });
    sit(player);
    if (!solo) {
      const appr = slotOf(companion).approach;
      if (companion.pos.distanceTo(slotOf(companion).pos) < 0.4) sit(companion); // already sitting there
      else {
        if (companion.pos.distanceTo(appr) > 45) companion.pos.copy(appr);
        companion.navigate(appr, () => sit(companion));
      }
    }
    a.standUp = c => {
      const s = slotOf(c);
      return [s.approach, s.yaw];
    };
  }

  // Face-to-face activity: companion walks up to the player.
  meet(def) {
    const player = this.lead, companion = this.other;
    const f = new THREE.Vector3(Math.sin(player.yaw), 0, Math.cos(player.yaw));
    const spotPos = player.pos.clone().addScaledVector(f, def.dist);
    spotPos.y = 0;
    const a = { ...def, elapsed: 0, ready: 0, need: 2, phase: 'gather', lineAt: 0, lines: def.lines ? [...def.lines] : [], participants: [player, companion] };
    this.cur = a;
    player.mode = 'busy';
    player.vel.set(0, 0, 0);
    player.speed = 0;
    player.setPose('idle');
    a.ready++;
    const face = () => {
      const d = player.pos.clone().sub(companion.pos);
      companion.snapTo(spotPos, Math.atan2(d.x, d.z), def.pose, def.opts, 0.35, () => { a.ready++; });
      const yawP = Math.atan2(-d.x, -d.z);
      player.snapTo(player.pos.clone().setY(0), yawP, def.pose, def.opts, 0.35);
    };
    companion.navigate(spotPos, face);
  }

  // Side-by-side standing moment; the companion walks up next to the player.
  sideBySide(def) {
    const player = this.lead, companion = this.other;
    const yaw = player.yaw;
    const lat = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
    const spotPos = player.pos.clone().addScaledVector(lat, def.gap ?? 0.52).setY(0);
    const a = { ...def, elapsed: 0, ready: 0, need: 2, phase: 'gather', lineAt: 0, lines: def.lines ? [...def.lines] : [], participants: [player, companion] };
    this.cur = a;
    player.mode = 'busy';
    player.vel.set(0, 0, 0);
    player.speed = 0;
    const poseOf = c => (c.female ? def.her : def.him);
    companion.navigate(spotPos, () => {
      const [cp, co] = poseOf(companion);
      companion.snapTo(spotPos, yaw, cp, { ...co, side: -1 }, 0.4, () => { a.ready++; });
      const [pp, po] = poseOf(player);
      player.snapTo(player.pos.clone().setY(0), yaw, pp, { ...po, side: 1 }, 0.4, () => { a.ready++; });
    });
  }

  // Local frame of a two-seat spot: forward, lateral (his local +X) and which side she sits on.
  seatFrame(spot) {
    const [s0, s1] = spot.slots;
    const yaw = s0.yaw;
    const fwd = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw));
    const lat = new THREE.Vector3(fwd.z, 0, -fwd.x);
    const side = Math.sign(lat.dot(s1.pos.clone().sub(s0.pos))) || 1;
    return { yaw, fwd, lat, side };
  }

  // Cuddle variants for a bench/sofa: cycled with C while seated.
  seatCuddles(spot, seatH) {
    const f = this.seatFrame(spot);
    const [s0, s1] = spot.slots;
    const [him, her] = this.g.chars;
    const at = (base, fo, lo) => base.clone().addScaledVector(f.fwd, fo).addScaledVector(f.lat, lo * f.side).setY(0);
    const lieYaw = Math.atan2(f.lat.x * f.side, f.lat.z * f.side);
    return [
      {
        name: 'Head on the shoulder', lines: LINES.shoulder, hearts: 4,
        apply: () => {
          him.snapTo(at(s0.pos, 0, 0.05), f.yaw, 'sit', { seatH, arm: 'around', side: f.side }, 0.6);
          her.snapTo(at(s1.pos, 0, -0.12), f.yaw, 'leanHead', { seatH, side: -f.side }, 0.6);
        },
      },
      {
        name: 'Holding hands', lines: LINES.hands, hearts: 3,
        apply: () => {
          him.snapTo(at(s0.pos, 0, 0), f.yaw, 'sit', { seatH, arm: 'hold', side: f.side, lean: s0.lean }, 0.6);
          her.snapTo(at(s1.pos, 0, 0), f.yaw, 'sit', { seatH, arm: 'hold', side: -f.side, lean: s1.lean }, 0.6);
        },
      },
      {
        name: `${her.name} on the lap`, lines: LINES.lap, hearts: 8,
        apply: () => {
          him.snapTo(at(s0.pos, 0, 0), f.yaw, 'sit', { seatH, arm: 'wrap', side: f.side }, 0.6);
          // She sits sideways across his lap so both faces stay visible.
          her.snapTo(at(s0.pos, 0.4, 0.05), lieYaw, 'lapSit', { seatH, side: f.side }, 0.7);
        },
      },
      {
        name: 'Head on the lap', lines: LINES.headLap, hearts: 5,
        apply: () => {
          him.snapTo(at(s0.pos, 0, 0), f.yaw, 'sit', { seatH, arm: 'stroke', side: f.side }, 0.6);
          // Lying down, the head sits ~1.6m back along her facing, so place the body that far out.
          her.snapTo(at(s0.pos, 0.22, 1.6), lieYaw, 'headLap', { bedH: seatH + 0.06 }, 0.7);
        },
      },
      {
        name: 'Sitting back up',
        apply: () => {
          him.snapTo(at(s0.pos, 0, 0), f.yaw, 'sit', { seatH, lean: s0.lean }, 0.6);
          her.snapTo(at(s1.pos, 0, 0), f.yaw, 'sit', { seatH, lean: s1.lean }, 0.6);
        },
      },
    ];
  }

  bedCuddles(spot) {
    const f = this.seatFrame(spot);
    const [s0, s1] = spot.slots;
    const [him, her] = this.g.chars;
    const bedH = spot.bedH;
    const at = (base, lo) => base.clone().addScaledVector(f.lat, lo * f.side).setY(0);
    return [
      {
        name: 'Snuggled up close', lines: LINES.snuggle, hearts: 6,
        apply: () => {
          him.snapTo(at(s0.pos, 0.16), f.yaw, 'sleep', { bedH, lean: s0.lean, arm: 'around', side: f.side }, 0.9);
          her.snapTo(at(s1.pos, -0.18), f.yaw, 'snuggle', { bedH, side: -f.side }, 0.9);
        },
      },
      {
        name: 'Holding hands under the blanket', lines: LINES.hands, hearts: 3,
        apply: () => {
          him.snapTo(at(s0.pos, 0), f.yaw, 'sleep', { bedH, lean: s0.lean, arm: 'hold', side: f.side }, 0.9);
          her.snapTo(at(s1.pos, 0), f.yaw, 'sleep', { bedH, lean: s1.lean, arm: 'hold', side: -f.side }, 0.9);
        },
      },
      {
        name: 'Just the two of you', lines: LINES.blanket, hearts: 14,
        apply: () => {
          him.snapTo(at(s0.pos, 0.2), f.yaw, 'snuggle', { bedH, side: f.side }, 1.0);
          her.snapTo(at(s1.pos, -0.22), f.yaw, 'snuggle', { bedH, side: -f.side }, 1.0);
        },
        fx: (dt, a, g) => {
          a.blanketT = (a.blanketT || 0) + dt;
          g.world.blanket.position.y = 1.02 + Math.sin(a.blanketT * 2.2) * 0.06;
          if (Math.floor(a.blanketT / 2) !== Math.floor((a.blanketT - dt) / 2)) this.heartsBetween(5);
        },
      },
      {
        name: 'Back to sleep',
        apply: () => {
          him.snapTo(at(s0.pos, 0), f.yaw, 'sleep', { bedH, lean: s0.lean }, 0.9);
          her.snapTo(at(s1.pos, 0), f.yaw, 'sleep', { bedH, lean: s1.lean }, 0.9);
          this.g.world.blanket.position.y = 1.02;
        },
      },
    ];
  }

  // Variants for a table where the two face each other.
  faceCuddles(spot, seatH) {
    const [s0, s1] = spot.slots;
    const [him, her] = this.g.chars;
    return [
      {
        name: 'Holding hands across the table', lines: LINES.hands, hearts: 5,
        apply: () => {
          him.snapTo(s0.pos.clone(), s0.yaw, 'sit', { seatH, arm: 'reach', side: 1 }, 0.6);
          her.snapTo(s1.pos.clone(), s1.yaw, 'sit', { seatH, arm: 'reach', side: -1 }, 0.6);
        },
      },
      {
        name: 'Sitting back up',
        apply: () => {
          him.snapTo(s0.pos.clone(), s0.yaw, 'sit', { seatH }, 0.6);
          her.snapTo(s1.pos.clone(), s1.yaw, 'sit', { seatH }, 0.6);
        },
      },
    ];
  }

  nextCuddleName() {
    const a = this.cur;
    if (!a?.cuddles || a.phase !== 'active') return null;
    const i = a.cuddleIdx === undefined ? 0 : (a.cuddleIdx + 1) % a.cuddles.length;
    return a.cuddles[i].name;
  }

  cycleCuddle() {
    const a = this.cur;
    if (!a?.cuddles || a.phase !== 'active') return false;
    a.cuddleIdx = a.cuddleIdx === undefined ? 0 : (a.cuddleIdx + 1) % a.cuddles.length;
    const v = a.cuddle = a.cuddles[a.cuddleIdx];
    a.blanketT = 0;
    v.apply();
    this.fx.toast(v.name);
    if (v.lines) { a.lines = [...v.lines]; a.lineAt = a.elapsed + 1.1; }
    if (v.hearts) this.heartsBetween(v.hearts);
    return true;
  }

  // `lead` is whoever asked for it; `partner` comes over, or null to do it alone.
  start(kind, lead, partner = null) {
    if (this.cur) return;
    this.lead = lead;
    this.other = partner;
    const g = this.g, w = g.world, s = w.spots;
    const duo = !!partner;
    switch (kind) {
      case 'bench': {
        const night = g.hours >= 19.5 || g.hours < 5.5;
        this.together(s.bench, {
          kind, pose: 'sit', lines: night ? LINES.stars : LINES.sunset, solo: night ? SOLO.stars : SOLO.sunset, cuddles: this.seatCuddles(s.bench, 0.47),
          camera: { pos: new THREE.Vector3(-50.2, 2.3, 1.2), look: new THREE.Vector3(-90, 3, -12) },
          onBegin: () => {
            if (!night && (g.hours < 17.4 || g.hours > 19.5)) { g.warpTo(18.1); this.fx.toast(duo ? 'Time flies when you are together...' : 'Time flies...'); }
            this.fx.toast(night ? 'Stargazing by the lake' : duo ? 'Watching the sunset together' : 'Watching the sunset');
          },
          onUpdate: (dt, a) => { if (Math.floor(a.elapsed / 3) !== Math.floor((a.elapsed - dt) / 3)) this.heartsBetween(); },
        });
        break;
      }
      case 'bed':
        this.together(s.bed, {
          kind, pose: 'sleep', lines: LINES.sleep, solo: SOLO.sleep, stand: 'Wake up', cuddles: this.bedCuddles(s.bed),
          camera: { pos: new THREE.Vector3(-5.5, 5.5, -10.8), look: new THREE.Vector3(-5.5, 0.6, -14.6) },
          onBegin: a => { w.blanket.position.y = 1.02; a.sleepT = 0; },
          onUpdate: (dt, a) => {
            // Cuddling keeps them awake; "Back to sleep" lets the night run again.
            if (a.cuddle && a.cuddle.name !== 'Back to sleep') { a.sleepT = 0; return; }
            const t0 = a.sleepT;
            a.sleepT += dt;
            if (t0 < 3.5 && a.sleepT >= 3.5) this.fx.fade(true);
            if (t0 < 5.2 && a.sleepT >= 5.2) g.setTime(7, true);
            if (t0 < 6.4 && a.sleepT >= 6.4) { this.fx.fade(false); this.fx.toast(duo ? 'Good morning, sleepyheads!' : 'Good morning!'); }
          },
          onEnd: () => { w.blanket.position.y = 0.65; this.fx.fade(false); },
        });
        break;
      case 'sofa':
        this.together(s.sofa, {
          kind, pose: 'sit', opts: { seatH: 0.47 }, lines: LINES.tv, solo: SOLO.tv, cuddles: this.seatCuddles(s.sofa, 0.47),
          onBegin: () => w.tv.setOn(true),
          onEnd: () => w.tv.setOn(false),
        });
        break;
      case 'homeTable':
      case 'cafeTable': {
        const date = kind === 'cafeTable';
        const food = date ? w.cafeFood : w.homeFood;
        this.together(s[kind], {
          kind, pose: 'eat', lines: date ? LINES.date : LINES.dinner, solo: date ? SOLO.date : SOLO.dinner, cuddles: this.faceCuddles(s[kind], 0.47),
          camera: date ? { pos: new THREE.Vector3(22, 2.4, 14.6), look: new THREE.Vector3(22, 1.0, 18) } : null,
          onBegin: a => { food.set(1); a.meal = 1; this.fx.toast(date ? (duo ? 'Date night at Café Amour' : 'Café Amour') : 'Dinner at home'); },
          onUpdate: (dt, a) => {
            if (a.meal <= 0) return;
            a.meal = Math.max(0, a.meal - dt / 16);
            food.set(a.meal);
            if (date && Math.floor(a.elapsed / 4) !== Math.floor((a.elapsed - dt) / 4)) this.heartsBetween();
            if (a.meal === 0) {
              this.fx.toast('That was delicious!');
              if (!a.cuddle) a.participants.forEach(c => c.setPose('sit', { seatH: 0.47 }));
            }
          },
          onEnd: () => food.set(0),
        });
        break;
      }
      case 'talk':
        this.meet({
          kind, dist: 1.3, pose: 'talk', lines: [...TALKS[(Math.random() * TALKS.length) | 0]], autoEndAfterLines: true,
        });
        break;
      case 'hug':
        this.meet({
          kind, dist: 0.55, pose: 'hug', lines: LINES.hug, autoEnd: 4.5,
          onBegin: () => this.heartsBetween(10),
        });
        break;
      case 'kiss':
        this.meet({
          kind, dist: 0.46, pose: 'kiss', lines: LINES.kiss, autoEnd: 4.2,
          onBegin: () => this.heartsBetween(12),
          onUpdate: (dt, a) => { if (Math.floor(a.elapsed / 1.4) !== Math.floor((a.elapsed - dt) / 1.4)) this.heartsBetween(3); },
        });
        break;
      case 'holdHands':
        this.sideBySide({
          kind, gap: 0.5, stand: 'Let go', lines: LINES.hands,
          him: ['idle', { arm: 'hold' }], her: ['idle', { arm: 'hold' }],
          onBegin: () => this.heartsBetween(3),
        });
        break;
      case 'lean':
        this.sideBySide({
          kind, gap: 0.46, stand: 'Stand apart', lines: LINES.standLean,
          him: ['idle', { arm: 'around' }], her: ['leanHead', {}],
          onBegin: () => this.heartsBetween(5),
          onUpdate: (dt, a) => { if (Math.floor(a.elapsed / 5) !== Math.floor((a.elapsed - dt) / 5)) this.heartsBetween(3); },
        });
        break;
      case 'dance':
        this.meet({
          kind, dist: 1.4, pose: 'dance',
          onBegin: () => this.fx.toast('Dance party!'),
          onUpdate: (dt, a) => { if (Math.floor(a.elapsed / 2) !== Math.floor((a.elapsed - dt) / 2)) this.heartsBetween(3); },
        });
        break;
    }
  }

  heartsBetween(n = 6) {
    if (!this.other) return;
    const p = this.g.chars[0].pos.clone().add(this.g.chars[1].pos).multiplyScalar(0.5);
    p.y += 1.9;
    if (this.cur?.pose === 'sleep') p.y = 1.6;
    this.fx.hearts(p, n);
  }

  update(dt) {
    const a = this.cur;
    if (!a) return;
    if (a.phase === 'gather') {
      a.gatherT = (a.gatherT || 0) + dt;
      if (a.ready >= a.need) {
        a.phase = 'active';
        a.onBegin?.(a);
      } else if (a.gatherT > 15) {
        this.end();
      }
      return;
    }
    a.elapsed += dt;
    a.onUpdate?.(dt, a);
    a.cuddle?.fx?.(dt, a, this.g);

    if (a.lines.length && a.elapsed >= a.lineAt) {
      const [sp, text] = a.lines.shift();
      const ch = this.speakerChar(sp);
      this.fx.say(ch, text.replaceAll('{him}', this.g.chars[0].name).replaceAll('{her}', this.g.chars[1].name), 2.7);
      if (a.pose === 'talk') a.participants.forEach(c => c.setPose('talk', { speaking: c === ch }));
      a.lineAt = a.elapsed + 3;
      if (!a.lines.length) a.linesDoneAt = a.lineAt;
    }
    if (a.autoEndAfterLines && !a.lines.length && a.elapsed >= a.linesDoneAt) this.end();
    else if (a.autoEnd && a.elapsed >= a.autoEnd) this.end();
  }

  // `quick` hands everyone back on the spot, without standing up first.
  end(quick = false) {
    const a = this.cur;
    if (!a) return;
    this.cur = null;
    a.onEnd?.(a);
    for (const c of a.participants) {
      const back = () => this.g.release(c);
      if (quick) {
        c.snap = null;
        back();
      } else if (a.standUp) {
        const [pos, yaw] = a.standUp(c);
        // Only stand if they actually reached their seat; otherwise just release them.
        if (c.mode === 'busy' || c.mode === 'snap') c.snapTo(pos, yaw, 'idle', {}, 0.5, back);
        else back();
      } else {
        c.setPose('idle');
        if (c.mode === 'snap') c.snapTo(c.pos.clone().setY(0), c.yaw, 'idle', {}, 0.2, back);
        else back();
      }
    }
  }
}
