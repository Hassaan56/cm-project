import * as THREE from 'three';
import { mat, box, cyl, clamp, damp, dampAngle, resolveCircle } from './utils.js';

export class Car {
  constructor(scene) {
    this.root = new THREE.Group();
    this.root.position.set(11.5, 0, -1.5);
    this.yaw = 0;
    this.speed = 0;
    this.steer = 0;
    this.owner = null; // index of the character driving it in multiplayer
    this.net = null;
    scene.add(this.root);

    const paint = mat('#d7263d', { roughness: 0.35, metalness: 0.4 });
    const dark = mat('#1d1d22', { roughness: 0.6 });
    const chrome = mat('#dddddd', { metalness: 0.9, roughness: 0.2 });
    const glass = mat('#2a3a55', { roughness: 0.1, metalness: 0.5, transparent: true, opacity: 0.75 });
    const r = this.root;
    r.add(box(1.9, 0.55, 4.1, paint, 0, 0.6, 0));
    r.add(box(1.92, 0.2, 1.2, paint, 0, 0.75, 1.5));
    const cabin = box(1.6, 0.55, 2.0, glass, 0, 1.15, -0.25); r.add(cabin);
    r.add(box(1.62, 0.08, 1.9, paint, 0, 1.45, -0.25));
    for (const x of [-0.79, 0.79]) for (const z of [-1.2, 0.7]) r.add(box(0.06, 0.55, 0.08, paint, x, 1.15, z));
    r.add(box(2.0, 0.18, 0.15, chrome, 0, 0.45, 2.08), box(2.0, 0.18, 0.15, chrome, 0, 0.45, -2.08));

    this.headMat = mat('#fffbe8', { emissive: '#fff6d0', emissiveIntensity: 0.2 });
    this.tailMat = mat('#ff2a2a', { emissive: '#ff0000', emissiveIntensity: 0.2 });
    for (const x of [-0.65, 0.65]) {
      r.add(box(0.35, 0.16, 0.05, this.headMat, x, 0.7, 2.06));
      r.add(box(0.35, 0.14, 0.05, this.tailMat, x, 0.7, -2.06));
    }

    this.wheels = [];
    this.frontPivots = [];
    for (const [x, z] of [[-0.95, 1.35], [0.95, 1.35], [-0.95, -1.35], [0.95, -1.35]]) {
      const pivot = new THREE.Group(); pivot.position.set(x, 0.38, z); r.add(pivot);
      const w = cyl(0.38, 0.38, 0.28, dark, 18); w.rotation.z = Math.PI / 2;
      const hub = cyl(0.18, 0.18, 0.3, chrome, 10); hub.rotation.z = Math.PI / 2;
      const spin = new THREE.Group(); spin.add(w, hub); pivot.add(spin);
      this.wheels.push(spin);
      if (z > 0) this.frontPivots.push(pivot);
    }

    this.lights = [-0.65, 0.65].map(x => {
      const s = new THREE.SpotLight('#fff3d6', 0, 45, 0.5, 0.5, 1.2);
      s.position.set(x, 0.75, 2.0);
      s.target.position.set(x, 0, 14);
      r.add(s, s.target);
      return s;
    });
    this.root.traverse(o => { if (o.isMesh) o.castShadow = true; });
  }

  get pos() { return this.root.position; }
  forward() { return new THREE.Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw)); }

  colliders() {
    const f = this.forward();
    return [
      { x: this.pos.x + f.x * 1.2, z: this.pos.z + f.z * 1.2, r: 1.0 },
      { x: this.pos.x - f.x * 1.2, z: this.pos.z - f.z * 1.2, r: 1.0 },
    ];
  }

  update(dt, input, colliders, night, driving) {
    if (driving) {
      const throttle = input.z, brake = input.jump;
      if (brake) this.speed = damp(this.speed, 0, 4, dt);
      else if (throttle > 0) this.speed += (this.speed < 0 ? 30 : 11) * dt;
      else if (throttle < 0) this.speed -= (this.speed > 0 ? 30 : 7) * dt;
      else this.speed = damp(this.speed, 0, 0.8, dt);
      this.speed = clamp(this.speed, -8, input.run ? 30 : 22);
      this.steer = damp(this.steer, -input.x * 0.55, 6, dt);
    } else {
      this.speed = damp(this.speed, 0, 3, dt);
      this.steer = damp(this.steer, 0, 3, dt);
    }
    const steerScale = 1 / (1 + Math.abs(this.speed) * 0.04);
    this.yaw += (this.speed * Math.tan(this.steer * steerScale) / 2.7) * dt;
    const f = this.forward();
    this.pos.addScaledVector(f, this.speed * dt);
    if (resolveCircle(this.pos, 1.7, colliders) && Math.abs(this.speed) > 2) this.speed *= -0.3;
    this.root.rotation.y = this.yaw;
    this.visuals(dt, driving && night > 0.3, driving && (input.jump || (input.z < 0 && this.speed > 0)), driving);
  }

  visuals(dt, lightsOn, braking, occupied) {
    for (const w of this.wheels) w.rotation.x += (this.speed / 0.38) * dt;
    for (const p of this.frontPivots) p.rotation.y = this.steer;
    for (const s of this.lights) s.intensity = lightsOn ? 120 : 0;
    this.headMat.emissiveIntensity = lightsOn ? 3 : 0.2;
    this.tailMat.emissiveIntensity = occupied ? (braking ? 3 : 1) : 0.2;
    this.lightsOn = lightsOn;
    this.braking = braking;
  }

  netState() {
    return { p: this.pos.toArray(), y: this.yaw, v: this.speed, st: this.steer, l: !!this.lightsOn, b: !!this.braking };
  }

  setNet(s, snap = false) {
    this.net = s;
    if (snap) { this.pos.fromArray(s.p); this.yaw = s.y; this.speed = s.v; this.root.rotation.y = this.yaw; }
  }

  // Follows the remote driver's car.
  applyNet(dt) {
    const n = this.net;
    if (!n) return;
    const k = 1 - Math.exp(-10 * dt);
    this.pos.x += (n.p[0] - this.pos.x) * k;
    this.pos.z += (n.p[2] - this.pos.z) * k;
    this.yaw = dampAngle(this.yaw, n.y, 10, dt);
    this.speed = n.v;
    this.steer = n.st;
    this.root.rotation.y = this.yaw;
    this.visuals(dt, n.l, n.b, true);
  }
}
